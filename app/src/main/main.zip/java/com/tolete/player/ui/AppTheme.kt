package com.tolete.player.ui

import android.graphics.BitmapFactory
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette
import com.tolete.player.ui.MusicViewModel.AppThemeId
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.sin

@Immutable
data class AppColors(
    val gradientTop: Color,
    val gradientBottom: Color,
    val accent: Color,
    val surface: Color,
    val isLight: Boolean = false,
    /** Até 5 cores extraídas da capa que "flutuam" no gradiente dinâmico. */
    val floatColors: List<Color> = emptyList()
) {
    val gradient: Brush get() = Brush.verticalGradient(listOf(gradientTop, gradientBottom))
    /** Segunda cor do tema (par com accent) — usada em barras, bordas e destaques. */
    val secondary: Color get() = gradientTop
}

/** Gradiente com deriva lenta (estilo floating) a partir das cores base do tema. */
@Composable
fun rememberFloatingGradient(colors: AppColors): Brush {
    val infinite = rememberInfiniteTransition(label = "themeFloat")
    val t by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12_000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "floatPhase"
    )
    val wave = (sin(t * Math.PI.toFloat()) * 0.5f + 0.5f)
    val shift = 0.06f + wave * 0.08f
    val floats = colors.floatColors.filter { it != Color.Unspecified }.take(5)
    if (floats.size >= 2) {
        // Interpola entre as cores selecionadas com deriva lenta (mais "vivo").
        val n = floats.size
        val phase = t * (n - 1).toFloat()
        val i0 = phase.toInt().coerceIn(0, n - 2)
        val i1 = (i0 + 1).coerceAtMost(n - 1)
        val localT = (phase - i0).coerceIn(0f, 1f)
        val cA = lerp(floats[i0], floats[i1], localT)
        val cB = lerp(
            floats[(i0 + n / 2) % n],
            floats[(i1 + n / 2) % n],
            localT
        )
        val top = lerp(cA, colors.gradientTop, 0.35f + shift * 0.4f)
        val bot = lerp(cB, colors.gradientBottom, 0.45f + shift * 0.3f)
        return Brush.verticalGradient(listOf(top, bot))
    }
    val topA = lerp(colors.gradientTop, colors.accent.copy(alpha = colors.gradientTop.alpha), shift * 0.45f)
    val topB = lerp(colors.gradientTop, colors.surface, shift)
    val botA = lerp(colors.gradientBottom, colors.surface, shift * 0.5f)
    val botB = lerp(colors.gradientBottom, colors.accent.copy(alpha = colors.gradientBottom.alpha), shift * 0.35f)
    return Brush.verticalGradient(
        colors = listOf(
            lerp(topA, topB, t * 0.5f),
            lerp(botA, botB, (1f - t) * 0.5f)
        )
    )
}

val DefaultAppColors = AppColors(
    gradientTop = Color(0xFF241440),
    gradientBottom = Color(0xFF0B0B14),
    accent = Color(0xFFBB86FC),
    surface = Color(0xFF1A1528)
)

val AquaColors = AppColors(
    gradientTop = Color(0xFF0A3D62),
    gradientBottom = Color(0xFF051B2C),
    accent = Color(0xFF00D2FF),
    surface = Color(0xFF0D2B3E)
)

val SunsetColors = AppColors(
    gradientTop = Color(0xFF4A1C2F),
    gradientBottom = Color(0xFF1A0A12),
    accent = Color(0xFFFF6B4A),
    surface = Color(0xFF2E1520)
)

val ForestColors = AppColors(
    gradientTop = Color(0xFF0F2E1C),
    gradientBottom = Color(0xFF06140C),
    accent = Color(0xFF4ADE80),
    surface = Color(0xFF143D28)
)

val MidnightColors = AppColors(
    gradientTop = Color(0xFF0B1220),
    gradientBottom = Color(0xFF02060E),
    accent = Color(0xFF60A5FA),
    surface = Color(0xFF121A2C)
)

val RoseColors = AppColors(
    gradientTop = Color(0xFF3B1228),
    gradientBottom = Color(0xFF160812),
    accent = Color(0xFFF472B6),
    surface = Color(0xFF2A1522)
)

val EmberColors = AppColors(
    gradientTop = Color(0xFF3D1A0A),
    gradientBottom = Color(0xFF140806),
    accent = Color(0xFFFBBF24),
    surface = Color(0xFF2A1408)
)

/** AMOLED: preto puro (#000000) para economia de bateria em telas OLED. */
val AmoledColors = AppColors(
    gradientTop = Color(0xFF000000),
    gradientBottom = Color(0xFF000000),
    accent = Color(0xFFBB86FC),
    surface = Color(0xFF0A0A0A)
)

/**
 * Twilight: tema baseado em cores de fundo de foto — crepúsculo (índigo profundo,
 * violeta suave e um toque de âmbar no accent), como o céu após o pôr do sol.
 */
val TwilightColors = AppColors(
    gradientTop = Color(0xFF1A1035),
    gradientBottom = Color(0xFF0A0618),
    accent = Color(0xFFC4A1FF),
    surface = Color(0xFF1E1438)
)

fun staticTheme(id: AppThemeId): AppColors = when (id) {
    AppThemeId.AQUA -> AquaColors
    AppThemeId.SUNSET -> SunsetColors
    AppThemeId.FOREST -> ForestColors
    AppThemeId.MIDNIGHT -> MidnightColors
    AppThemeId.ROSE -> RoseColors
    AppThemeId.EMBER -> EmberColors
    AppThemeId.AMOLED -> AmoledColors
    AppThemeId.TWILIGHT -> TwilightColors
    AppThemeId.DEFAULT, AppThemeId.DYNAMIC -> DefaultAppColors
}

/**
 * Extrai várias cores da capa (topo + base + accent + até 5 swatches para flutuarem).
 */
fun colorsFromArt(
    artPath: String?,
    fallback: AppColors = DefaultAppColors,
    preferredFloatIndices: List<Int> = emptyList()
): AppColors {
    if (artPath.isNullOrBlank()) return fallback
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(artPath, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 128 && bounds.outHeight / (sample * 2) >= 128) sample *= 2
        val bmp = BitmapFactory.decodeFile(
            artPath,
            BitmapFactory.Options().apply { inSampleSize = sample }
        ) ?: return fallback
        val palette = Palette.from(bmp).maximumColorCount(24).generate()
        bmp.recycle()

        val dominant = palette.getDominantColor(fallback.gradientBottom.toArgb())
        val darkVibrant = palette.getDarkVibrantColor(
            palette.getDarkMutedColor(dominant)
        )
        val vibrant = palette.getVibrantColor(
            palette.getMutedColor(fallback.accent.toArgb())
        )
        val lightVibrant = palette.getLightVibrantColor(vibrant)
        val muted = palette.getMutedColor(dominant)
        val darkMuted = palette.getDarkMutedColor(dominant)

        fun darken(argb: Int, maxV: Float): Color {
            val hsv = FloatArray(3)
            android.graphics.Color.colorToHSV(argb, hsv)
            hsv[2] = hsv[2].coerceAtMost(maxV)
            return Color(android.graphics.Color.HSVToColor(hsv))
        }

        val top = darken(darkVibrant, 0.35f)
        val bottom = darken(dominant, 0.16f)
        val accentColor = Color(if (vibrant != dominant) vibrant else lightVibrant)

        // Coleta swatches distintos (até 8) ordenados por população
        val candidates = palette.swatches
            .sortedByDescending { it.population }
            .map { Color(it.rgb) }
            .distinctBy { (it.red * 10).toInt() * 100 + (it.green * 10).toInt() * 10 + (it.blue * 10).toInt() }
            .take(8)
            .ifEmpty {
                listOf(
                    accentColor,
                    Color(vibrant),
                    Color(muted),
                    Color(darkMuted),
                    Color(lightVibrant)
                )
            }

        val selectedFloats = if (preferredFloatIndices.isNotEmpty()) {
            preferredFloatIndices.mapNotNull { idx -> candidates.getOrNull(idx) }.take(5)
        } else {
            candidates.take(5)
        }

        AppColors(
            gradientTop = top,
            gradientBottom = bottom,
            accent = accentColor,
            surface = top.copy(alpha = 0.92f),
            floatColors = selectedFloats
        )
    } catch (_: Exception) {
        fallback
    } catch (_: OutOfMemoryError) {
        fallback
    }
}

/** Monta AppColors a partir de uma cor de destaque escolhida pelo usuário (tema dinâmico idle). */
fun colorsFromSeed(seed: Color): AppColors {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(seed.toArgb(), hsv)
    val darkTop = Color.hsv(hsv[0], (hsv[1] * 0.55f).coerceIn(0f, 1f), (hsv[2] * 0.28f).coerceIn(0.08f, 0.4f))
    val darkBot = Color.hsv(hsv[0], (hsv[1] * 0.4f).coerceIn(0f, 1f), (hsv[2] * 0.12f).coerceIn(0.04f, 0.2f))
    val surface = Color.hsv(hsv[0], (hsv[1] * 0.35f).coerceIn(0f, 1f), (hsv[2] * 0.18f).coerceIn(0.06f, 0.28f))
    return AppColors(
        gradientTop = darkTop,
        gradientBottom = darkBot,
        accent = seed,
        surface = surface
    )
}

@Composable
fun rememberAppColors(
    themeId: AppThemeId,
    artPath: String?,
    isPlaying: Boolean,
    dynamicDefaultArgb: Int = 0xFFBB86FC.toInt(),
    /** Cores manuais (ARGB) para flutuarem no dinâmico; vazio = auto da capa. */
    dynamicFloatArgb: List<Int> = emptyList()
): AppColors {
    val manualFloats = remember(dynamicFloatArgb) {
        dynamicFloatArgb.map { Color(it) }.take(5)
    }
    val dynamicIdle = remember(dynamicDefaultArgb, manualFloats) {
        colorsFromSeed(Color(dynamicDefaultArgb)).copy(floatColors = manualFloats)
    }
    val fixed = remember(themeId, dynamicDefaultArgb, manualFloats) {
        if (themeId == AppThemeId.DYNAMIC) dynamicIdle else staticTheme(themeId)
    }
    val useArt = themeId == AppThemeId.DYNAMIC && isPlaying
    val fromArt by produceState(initialValue = dynamicIdle, artPath, useArt, dynamicDefaultArgb, manualFloats) {
        if (useArt) {
            val extracted = withContext(Dispatchers.Default) { colorsFromArt(artPath, dynamicIdle) }
            // Preferência do usuário sobrepõe as cores auto da capa quando definida.
            value = if (manualFloats.isNotEmpty()) {
                extracted.copy(floatColors = manualFloats)
            } else {
                extracted
            }
        } else {
            value = dynamicIdle
        }
    }
    val target = if (useArt) fromArt else fixed
    val top by animateColorAsState(target.gradientTop, tween(550), label = "gradTop")
    val bottom by animateColorAsState(target.gradientBottom, tween(550), label = "gradBottom")
    val accent by animateColorAsState(target.accent, tween(550), label = "accent")
    val surface by animateColorAsState(target.surface, tween(550), label = "surface")
    return AppColors(
        gradientTop = top,
        gradientBottom = bottom,
        accent = accent,
        surface = surface,
        isLight = target.isLight,
        floatColors = target.floatColors
    )
}


/**
 * Escala de layout relativa a um telefone de referência (~400dp de largura, ~800dp de altura).
 * DPI/tamanho de tela diferentes encolhem ou expandem paddings, capas e controles
 * para evitar overflow em telas compactas e vazios excessivos em telas grandes.
 */
@Immutable
data class LayoutScale(
    val widthDp: Int,
    val heightDp: Int,
    /** 1f = referência; <1 = tela menor. */
    val factor: Float,
    val compact: Boolean
) {
    fun dp(value: Float): Dp = (value * factor).dp
    fun dp(value: Int): Dp = (value * factor).dp
    fun sp(value: Float): TextUnit = (value * factor.coerceIn(0.85f, 1.1f)).sp
    fun sp(value: Int): TextUnit = (value * factor.coerceIn(0.85f, 1.1f)).sp
}

@Composable
fun rememberLayoutScale(): LayoutScale {
    val cfg = LocalConfiguration.current
    val w = cfg.screenWidthDp.coerceAtLeast(1)
    val h = cfg.screenHeightDp.coerceAtLeast(1)
    // Referência confortável (~DPI 420 em muitos celulares médios)
    val refW = 400f
    val refH = 820f
    val wf = (w / refW).coerceIn(0.72f, 1.2f)
    val hf = (h / refH).coerceIn(0.68f, 1.2f)
    // Altura costuma ser o gargalo no Now Playing
    val factor = minOf(wf, hf)
    val compact = h < 720 || w < 340
    return remember(w, h) { LayoutScale(w, h, factor, compact) }
}
