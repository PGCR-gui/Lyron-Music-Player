package com.tolete.player.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tolete.player.data.TagReader
import com.tolete.player.data.TagWriter
import com.tolete.player.data.Track
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Campos do editor experimental completo. */
data class TagEdits(
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val albumArtist: String = "",
    val genre: String = "",
    val year: String = "",
    val trackNumber: String = "",
    val trackTotal: String = "",
    val disc: String = "",
    val discTotal: String = "",
    val composer: String = "",
    val lyricist: String = "",
    val comment: String = "",
    val lyrics: String = "",
    val bpm: String = "",
    val isrc: String = "",
    val copyright: String = "",
    val encoder: String = "",
    val publisher: String = "",
    val originalArtist: String = "",
    val originalYear: String = "",
    /** Nova capa (JPEG já reduzido) escolhida no editor; null = manter a atual. */
    val cover: ByteArray? = null,
    /** true só se o usuário esvaziou de propósito uma letra que existia. */
    val clearLyrics: Boolean = false
)

fun TagEdits.toWriterFields() = TagWriter.Fields(
    title = title,
    artist = artist,
    album = album,
    albumArtist = albumArtist,
    genre = genre,
    year = year,
    track = trackNumber,
    trackTotal = trackTotal,
    disc = disc,
    discTotal = discTotal,
    composer = composer,
    lyricist = lyricist,
    comment = comment,
    lyrics = lyrics,
    clearLyrics = clearLyrics,
    bpm = bpm,
    isrc = isrc,
    copyright = copyright,
    encoder = encoder,
    publisher = publisher,
    originalArtist = originalArtist,
    originalYear = originalYear,
    cover = cover
)

@Composable
fun TagEditorScreen(
    track: Track,
    appColors: AppColors,
    onSave: (TagEdits) -> Unit,
    onClose: () -> Unit,
    isPlaying: Boolean = false,
    getPosition: () -> Long = { 0L },
    onSeek: (Long) -> Unit = {},
    onToggle: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var title by remember(track.id) { mutableStateOf(track.title) }
    var artist by remember(track.id) { mutableStateOf(track.artist) }
    var album by remember(track.id) { mutableStateOf(track.album) }
    var albumArtist by remember(track.id) { mutableStateOf("") }
    var genre by remember(track.id) { mutableStateOf(track.genre) }
    var year by remember(track.id) { mutableStateOf(track.year?.toString().orEmpty()) }
    var trackNumber by remember(track.id) { mutableStateOf(track.trackNumber?.toString().orEmpty()) }
    var trackTotal by remember(track.id) { mutableStateOf("") }
    var disc by remember(track.id) { mutableStateOf("") }
    var discTotal by remember(track.id) { mutableStateOf("") }
    var composer by remember(track.id) { mutableStateOf("") }
    var lyricist by remember(track.id) { mutableStateOf("") }
    var comment by remember(track.id) { mutableStateOf("") }
    var lyrics by remember(track.id) { mutableStateOf("") }
    // Letra como estava no arquivo ao abrir (para saber se o usuário a apagou de propósito)
    var originalLyrics by remember(track.id) { mutableStateOf("") }
    var bpm by remember(track.id) { mutableStateOf("") }
    var isrc by remember(track.id) { mutableStateOf("") }
    var copyright by remember(track.id) { mutableStateOf("") }
    var encoder by remember(track.id) { mutableStateOf("") }
    var publisher by remember(track.id) { mutableStateOf("") }
    var originalArtist by remember(track.id) { mutableStateOf("") }
    var originalYear by remember(track.id) { mutableStateOf("") }

    var techLine by remember(track.id) { mutableStateOf<String?>(null) }
    var loading by remember(track.id) { mutableStateOf(true) }
    var showLyricsSync by remember { mutableStateOf(false) }
    var fileHint by remember(track.id) { mutableStateOf<String?>(null) }
    var localArtPath by remember(track.id) { mutableStateOf(track.artPath) }
    var savingArt by remember { mutableStateOf(false) }

    // A capa só é gravada no arquivo ao tocar em "Salvar", junto com as tags.
    var pendingCover by remember(track.id) { mutableStateOf<ByteArray?>(null) }

    var showOnlineLookup by remember { mutableStateOf(false) }
    var onlineLoading by remember { mutableStateOf(false) }
    var onlineResults by remember { mutableStateOf<List<com.tolete.player.data.TagLookupClient.Result>>(emptyList()) }
    var onlineError by remember { mutableStateOf<String?>(null) }

    val pickCoverLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            savingArt = true
            // Decodifica, reduz (máx. 1400 px) e converte p/ JPEG: aceita PNG/WebP/HEIC e evita arquivos enormes.
            val prepared: Pair<ByteArray, String>? = withContext(Dispatchers.IO) {
                try {
                    val cr = context.contentResolver
                    val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    cr.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) }
                    var sample = 1
                    val maxSide = maxOf(opts.outWidth, opts.outHeight)
                    while (maxSide / sample > 2800) sample *= 2
                    val decodeOpts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
                    var bmp = cr.openInputStream(uri)?.use {
                        android.graphics.BitmapFactory.decodeStream(it, null, decodeOpts)
                    } ?: return@withContext null
                    val side = maxOf(bmp.width, bmp.height)
                    if (side > 1400) {
                        val k = 1400f / side
                        val scaled = android.graphics.Bitmap.createScaledBitmap(
                            bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true
                        )
                        if (scaled !== bmp) bmp.recycle()
                        bmp = scaled
                    }
                    val out = java.io.ByteArrayOutputStream()
                    // Fundo branco para PNGs com transparência
                    val flat = android.graphics.Bitmap.createBitmap(bmp.width, bmp.height, android.graphics.Bitmap.Config.ARGB_8888)
                    android.graphics.Canvas(flat).apply {
                        drawColor(android.graphics.Color.WHITE)
                        drawBitmap(bmp, 0f, 0f, null)
                    }
                    flat.compress(android.graphics.Bitmap.CompressFormat.JPEG, 93, out)
                    bmp.recycle(); flat.recycle()
                    val bytes = out.toByteArray()
                    bytes to TagWriter.saveCoverPreview(context, bytes, "image/jpeg")
                } catch (e: Throwable) {
                    null
                }
            }
            savingArt = false
            if (prepared == null) {
                Toast.makeText(context, "Não foi possível ler a imagem", Toast.LENGTH_SHORT).show()
            } else {
                pendingCover = prepared.first
                localArtPath = prepared.second
                Toast.makeText(context, "Capa selecionada. Toque em Salvar para gravar.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun currentEdits() = TagEdits(
        title, artist, album, albumArtist, genre, year,
        trackNumber, trackTotal, disc, discTotal,
        composer, lyricist, comment, lyrics,
        bpm, isrc, copyright, encoder, publisher,
        originalArtist, originalYear,
        pendingCover,
        clearLyrics = originalLyrics.isNotBlank() && lyrics.isBlank()
    )

    fun applyTags(t: TagReader.Tags) {
        title = t.title ?: title
        artist = t.artist ?: artist
        album = t.album ?: album
        albumArtist = t.albumArtist.orEmpty()
        genre = t.genre ?: genre
        year = t.year ?: year
        trackNumber = t.track ?: trackNumber
        trackTotal = t.trackTotal.orEmpty()
        disc = t.disc.orEmpty()
        discTotal = t.discTotal.orEmpty()
        composer = t.composer.orEmpty()
        lyricist = t.lyricist.orEmpty()
        comment = t.comment.orEmpty()
        lyrics = t.lyrics.orEmpty()
        originalLyrics = lyrics
        bpm = t.bpm.orEmpty()
        isrc = t.isrc.orEmpty()
        copyright = t.copyright.orEmpty()
        encoder = t.encoder.orEmpty()
        publisher = t.publisher.orEmpty()
        originalArtist = t.originalArtist.orEmpty()
        originalYear = t.originalYear.orEmpty()

        val parts = mutableListOf<String>()
        t.format?.let { parts += it }
        if (t.sampleRate > 0) parts += "${t.sampleRate} Hz"
        if (t.bitDepth > 0) parts += "${t.bitDepth}-bit"
        if (t.bitRate > 0) parts += "${t.bitRate / 1000} kbps"
        if (t.channels > 0) parts += if (t.channels == 1) "Mono" else "${t.channels} ch"
        if (t.durationMs > 0) {
            val s = (t.durationMs / 1000).toInt()
            parts += "%d:%02d".format(s / 60, s % 60)
        }
        if (t.hasArtwork) parts += "capa"
        techLine = parts.joinToString(" · ").ifBlank { null }
    }

    fun reloadFromFile() {
        loading = true
        scope.launch {
            val tags = withContext(Dispatchers.IO) {
                TagReader.read(context, track)
            }
            if (tags != null) {
                applyTags(tags)
                if (tags.lyrics.isNullOrBlank()) {
                    // Letra pode estar em outra tag (UNSYNCEDLYRICS/SYNCEDLYRICS, USLT/SYLT):
                    // mostra no campo para o editor de letras não abrir vazio.
                    val extra = withContext(Dispatchers.IO) {
                        try {
                            val l = com.tolete.player.data.LyricsExtractor.loadEmbedded(context, track)
                            if (l.isEmpty()) "" else com.tolete.player.data.LyricsEmbedder.linesToLrcText(l).trimEnd()
                        } catch (_: Throwable) { "" }
                    }
                    if (extra.isNotBlank()) {
                        lyrics = extra
                        originalLyrics = extra
                    }
                }
                fileHint = "Lido do ficheiro via JAudioTagger"
            } else {
                fileHint = "Não foi possível ler o ficheiro (path real / “Todos os ficheiros”)"
                Toast.makeText(context, fileHint, Toast.LENGTH_SHORT).show()
            }
            loading = false
        }
    }

    LaunchedEffect(track.id) {
        reloadFromFile()
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White.copy(0.92f),
        focusedBorderColor = appColors.accent,
        unfocusedBorderColor = Color.White.copy(0.25f),
        cursorColor = appColors.accent,
        focusedLabelColor = appColors.accent,
        unfocusedLabelColor = Color.White.copy(0.55f),
        focusedContainerColor = Color.White.copy(0.06f),
        unfocusedContainerColor = Color.White.copy(0.04f)
    )

    Box(Modifier.fillMaxSize()) {
        // Fundo: capa borrada da faixa em edição
        val art = localArtPath
        if (art != null) {
            AsyncImage(
                model = File(art),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .blur(28.dp, BlurredEdgeTreatment.Unbounded)
            )
        } else {
            Box(Modifier.fillMaxSize().background(appColors.gradient))
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Black.copy(0.55f),
                            Color.Black.copy(0.70f),
                            Color.Black.copy(0.85f)
                        )
                    )
                )
        )
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Voltar", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text("Editor de tags", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(
                    "Experimental · JAudioTagger",
                    fontSize = 12.sp,
                    color = Color.White.copy(0.55f)
                )
            }
            IconButton(onClick = { reloadFromFile() }, enabled = !loading) {
                Icon(Icons.Rounded.Refresh, contentDescription = "Reler do ficheiro", tint = Color.White)
            }
            IconButton(
                onClick = { onSave(currentEdits()) },
                enabled = !loading
            ) {
                Icon(Icons.Rounded.Check, contentDescription = "Salvar", tint = appColors.accent)
            }
        }

        if (loading) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator(color = appColors.accent)
            }
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                track.path.ifBlank { track.uri.toString() },
                fontSize = 11.sp,
                color = Color.White.copy(0.4f),
                maxLines = 2
            )
            var renomearPorTags by remember { mutableStateOf(false) }
            var renamePattern by remember { mutableStateOf("%ARTIST% - %TITLE%") }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .clickable { renomearPorTags = !renomearPorTags },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = renomearPorTags,
                    onCheckedChange = { renomearPorTags = it }
                )
                Text("Renomear arquivo por tags ao salvar", fontSize = 14.sp)
            }
            if (renomearPorTags) {
                OutlinedTextField(
                    value = renamePattern,
                    onValueChange = { renamePattern = it },
                    label = { Text("Padrão") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Text(
                    "%ARTIST% %TITLE% %ALBUM% %ALBUM_ARTIST% %TRACK% %YEAR%",
                    fontSize = 11.sp,
                    color = Color.White.copy(0.45f)
                )
            }
            fileHint?.let {
                Text(it, fontSize = 12.sp, color = Color.White.copy(0.5f), modifier = Modifier.padding(top = 4.dp))
            }
            techLine?.let {
                Text(
                    it,
                    fontSize = 12.sp,
                    color = appColors.accent.copy(0.9f),
                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                )
            }

            SectionTitle("Capa")
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(96.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White.copy(0.08f))
                        .border(1.dp, Color.White.copy(0.2f), RoundedCornerShape(14.dp))
                        .clickable(enabled = !savingArt) { pickCoverLauncher.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    if (localArtPath != null) {
                        AsyncImage(
                            model = File(localArtPath!!),
                            contentDescription = "Capa",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(Icons.Rounded.Image, contentDescription = null, tint = Color.White.copy(0.5f), modifier = Modifier.size(36.dp))
                    }
                    if (savingArt) {
                        Box(Modifier.fillMaxSize().background(Color.Black.copy(0.5f)), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = appColors.accent, modifier = Modifier.size(28.dp))
                        }
                    }
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Trocar foto / capa", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color.White)
                    Text(
                        "Escolha uma imagem da galeria. A nova capa é gravada no arquivo ao tocar em Salvar.",
                        fontSize = 12.sp,
                        color = Color.White.copy(0.5f)
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { pickCoverLauncher.launch("image/*") },
                        enabled = !savingArt,
                        colors = ButtonDefaults.buttonColors(containerColor = appColors.accent)
                    ) {
                        Text("Escolher imagem", color = Color.Black)
                    }
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = {
                            showOnlineLookup = true
                            onlineLoading = true
                            onlineError = null
                            onlineResults = emptyList()
                            scope.launch {
                                try {
                                    onlineResults = com.tolete.player.data.TagLookupClient.search(
                                        title = title,
                                        artist = artist,
                                        album = album
                                    )
                                    if (onlineResults.isEmpty()) {
                                        onlineError = "Nenhum resultado encontrado"
                                    }
                                } catch (e: Exception) {
                                    onlineError = e.message ?: "Falha na busca"
                                } finally {
                                    onlineLoading = false
                                }
                            }
                        },
                        enabled = !savingArt && !onlineLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(0.18f))
                    ) {
                        Text("Buscar tags e capa online", color = Color.White)
                    }
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = {
                            onlineLoading = true
                            onlineError = null
                            scope.launch {
                                try {
                                    val results = com.tolete.player.data.TagLookupClient.search(
                                        title = title,
                                        artist = artist,
                                        album = album
                                    )
                                    val withCover = results.firstOrNull { !it.coverUrl.isNullOrBlank() }
                                    if (withCover == null) {
                                        onlineError = "Nenhuma capa encontrada"
                                        Toast.makeText(context, onlineError, Toast.LENGTH_SHORT).show()
                                    } else {
                                        val bytes = withContext(Dispatchers.IO) {
                                            com.tolete.player.data.TagLookupClient.downloadCover(withCover.coverUrl!!)
                                        }
                                        if (bytes != null) {
                                            pendingCover = bytes
                                            localArtPath = withContext(Dispatchers.IO) {
                                                com.tolete.player.data.TagWriter.saveCoverPreview(context, bytes, "image/jpeg")
                                            }
                                            Toast.makeText(context, "Capa aplicada no formulário. Salve para gravar.", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(context, "Falha ao baixar a capa", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                } catch (e: Exception) {
                                    onlineError = e.message ?: "Falha na busca de capa"
                                    Toast.makeText(context, onlineError, Toast.LENGTH_SHORT).show()
                                } finally {
                                    onlineLoading = false
                                }
                            }
                        },
                        enabled = !savingArt && !onlineLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(0.12f))
                    ) {
                        Text("Buscar apenas a capa do álbum", color = Color.White)
                    }
                }
            }

            SectionTitle("Básico")
            TagField("Título", title, fieldColors) { title = it }
            TagField("Artista", artist, fieldColors) { artist = it }
            TagField("Álbum", album, fieldColors) { album = it }
            TagField("Artista do álbum", albumArtist, fieldColors) { albumArtist = it }
            TagField("Género", genre, fieldColors) { genre = it }

            SectionTitle("Números")
            Row(Modifier.fillMaxWidth()) {
                TagField("Faixa", trackNumber, fieldColors, Modifier.weight(1f)) { trackNumber = it }
                Spacer(Modifier.width(10.dp))
                TagField("Total faixas", trackTotal, fieldColors, Modifier.weight(1f)) { trackTotal = it }
            }
            Row(Modifier.fillMaxWidth()) {
                TagField("Disco", disc, fieldColors, Modifier.weight(1f)) { disc = it }
                Spacer(Modifier.width(10.dp))
                TagField("Total discos", discTotal, fieldColors, Modifier.weight(1f)) { discTotal = it }
            }
            Row(Modifier.fillMaxWidth()) {
                TagField("Ano", year, fieldColors, Modifier.weight(1f)) { year = it }
                Spacer(Modifier.width(10.dp))
                TagField("BPM", bpm, fieldColors, Modifier.weight(1f)) { bpm = it }
            }

            SectionTitle("Pessoas")
            TagField("Compositor", composer, fieldColors) { composer = it }
            TagField("Letrista", lyricist, fieldColors) { lyricist = it }
            TagField("Artista original", originalArtist, fieldColors) { originalArtist = it }
            TagField("Ano original", originalYear, fieldColors) { originalYear = it }

            SectionTitle("Extra")
            TagField("Editora / selo", publisher, fieldColors) { publisher = it }
            TagField("ISRC", isrc, fieldColors) { isrc = it }
            TagField("Copyright", copyright, fieldColors) { copyright = it }
            TagField("Encoder", encoder, fieldColors) { encoder = it }
            TagField("Comentário", comment, fieldColors, singleLine = false, minLines = 2) { comment = it }
            TagField("Letras (embed)", lyrics, fieldColors, singleLine = false, minLines = 4) { lyrics = it }
            Button(
                onClick = { showLyricsSync = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = appColors.accent,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Sincronizar letras", fontWeight = FontWeight.SemiBold)
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Campos vazios apagam a tag no ficheiro (quando o formato permite). " +
                    "Nem todos os formatos suportam todos os campos (ex.: WAV tem suporte limitado).",
                fontSize = 11.sp,
                color = Color.White.copy(0.45f)
            )
            Spacer(Modifier.height(24.dp))
        }

        Button(
            onClick = { onSave(currentEdits()) },
            enabled = !loading,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = appColors.accent,
                contentColor = Color.Black
            )
        ) {
            Text("Salvar no arquivo", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        } // Column content

        if (showOnlineLookup) {
            AppAlertDialog(
                onDismissRequest = { if (!onlineLoading) showOnlineLookup = false },
                title = { Text("Resultados online") },
                text = {
                    when {
                        onlineLoading -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(22.dp), color = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(12.dp))
                                Text("Buscando no Deezer e Last.fm…")
                            }
                        }
                        onlineError != null && onlineResults.isEmpty() -> {
                            Text(onlineError ?: "Sem resultados")
                        }
                        else -> {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(360.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(onlineResults) { r ->
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(MaterialTheme.colorScheme.onSurface.copy(0.08f))
                                            .clickable {
                                                // Aplica tags no formulário (preview antes de Salvar)
                                                if (r.title.isNotBlank()) title = r.title
                                                if (r.artist.isNotBlank()) artist = r.artist
                                                if (r.album.isNotBlank()) album = r.album
                                                r.year?.takeIf { it.isNotBlank() }?.let { year = it }
                                                r.genre?.takeIf { it.isNotBlank() }?.let { genre = it }
                                                r.trackNumber?.takeIf { it.isNotBlank() }?.let { trackNumber = it }
                                                val coverUrl = r.coverUrl
                                                if (!coverUrl.isNullOrBlank()) {
                                                    savingArt = true
                                                    scope.launch {
                                                        try {
                                                            val bytes = withContext(Dispatchers.IO) {
                                                                com.tolete.player.data.TagLookupClient.downloadCover(coverUrl)
                                                            }
                                                            if (bytes != null) {
                                                                pendingCover = bytes
                                                                localArtPath = withContext(Dispatchers.IO) {
                                                                    com.tolete.player.data.TagWriter.saveCoverPreview(
                                                                        context, bytes, "image/jpeg"
                                                                    )
                                                                }
                                                                Toast.makeText(
                                                                    context,
                                                                    "Tags e capa aplicadas no formulário. Toque em Salvar para gravar.",
                                                                    Toast.LENGTH_LONG
                                                                ).show()
                                                            } else {
                                                                Toast.makeText(
                                                                    context,
                                                                    "Tags aplicadas. Não foi possível baixar a capa.",
                                                                    Toast.LENGTH_SHORT
                                                                ).show()
                                                            }
                                                        } finally {
                                                            savingArt = false
                                                            showOnlineLookup = false
                                                        }
                                                    }
                                                } else {
                                                    Toast.makeText(
                                                        context,
                                                        "Tags aplicadas no formulário. Toque em Salvar para gravar.",
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                    showOnlineLookup = false
                                                }
                                            }
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            Modifier
                                                .size(56.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(MaterialTheme.colorScheme.onSurface.copy(0.1f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (!r.coverUrl.isNullOrBlank()) {
                                                AsyncImage(
                                                    model = r.coverUrl,
                                                    contentDescription = null,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                            } else {
                                                Icon(
                                                    Icons.Rounded.Image,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.onSurface.copy(0.4f)
                                                )
                                            }
                                        }
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(r.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                            Text(
                                                listOf(r.artist, r.album).filter { it.isNotBlank() }.joinToString(" · "),
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurface.copy(0.7f),
                                                maxLines = 2
                                            )
                                            Text(r.source, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary.copy(0.9f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showOnlineLookup = false }, enabled = !onlineLoading) {
                        Text("Fechar")
                    }
                }
            )
        }

        if (showLyricsSync) {
            val initialLines = remember(lyrics) {
                com.tolete.player.data.LyricsExtractor.parseLyricsContent(lyrics)
            }
            LyricsEditorScreen(
                track = track,
                initialLines = initialLines,
                isPlaying = isPlaying,
                getPosition = getPosition,
                onSeek = onSeek,
                onToggle = onToggle,
                onSave = { lines, _ ->
                    lyrics = lyricLinesToTagText(lines)
                    showLyricsSync = false
                },
                onClose = { showLyricsSync = false },
                appColors = appColors
            )
        }
    } // Box root
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = Color.White.copy(0.55f),
        modifier = Modifier.padding(top = 18.dp, bottom = 8.dp)
    )
    HorizontalDivider(color = Color.White.copy(0.12f), thickness = 1.dp)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun TagField(
    label: String,
    value: String,
    colors: androidx.compose.material3.TextFieldColors,
    modifier: Modifier = Modifier.fillMaxWidth(),
    singleLine: Boolean = true,
    minLines: Int = 1,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        minLines = minLines,
        modifier = modifier.padding(bottom = 8.dp),
        colors = colors,
        shape = RoundedCornerShape(12.dp)
    )
}
