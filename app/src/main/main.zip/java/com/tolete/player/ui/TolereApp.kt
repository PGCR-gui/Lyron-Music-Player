package com.tolete.player.ui

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.material3.RadioButton

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import com.tolete.player.R
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material.icons.Icons
import androidx.compose.ui.zIndex
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.rounded.Done
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.foundation.lazy.grid.items as lazyGridItems
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextFieldDefaults
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.Text
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.TextButton
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionOnScreen
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.tolete.player.data.Album
import com.tolete.player.data.Artist
import com.tolete.player.data.ArtistMetaStore
import com.tolete.player.data.LastFmClient
import com.tolete.player.data.Genre
import com.tolete.player.data.Playlist
import com.tolete.player.data.Track
import com.tolete.player.data.LyricLine
import com.tolete.player.data.LyricsEmbedder
import java.io.File

/** Fonte padrão da interface (não afeta letras). Null = sistema. */
val LocalUiFontFamily = staticCompositionLocalOf<FontFamily?> { null }

private data class GroupItem(
    val title: String,
    val subtitle: String,
    val key: String,
    val artPath: String? = null,
    val round: Boolean = false,
    val isFavorites: Boolean = false
)

private fun faixas(n: Int) = if (n == 1) "1 faixa" else "$n faixas"

/** Fundo padrão das telas do app (fallback estático). */
internal val AppGradient = Brush.verticalGradient(listOf(Color(0xFF241440), Color(0xFF0B0B14)))

/** Faz a tela consumir todos os toques, para não "vazarem" para a tela de baixo. */
internal fun Modifier.pointerBlock(): Modifier = pointerInput(Unit) {}

internal fun formatDuration(ms: Long): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

private fun tabTitle(tab: MusicViewModel.Tab) = when (tab) {
    MusicViewModel.Tab.HOME -> "Início"
    MusicViewModel.Tab.ALL -> "Todas as músicas"
    MusicViewModel.Tab.ARTISTS -> "Artistas"
    MusicViewModel.Tab.ALBUMS -> "Álbuns"
    MusicViewModel.Tab.GENRES -> "Gêneros"
    MusicViewModel.Tab.PLAYLISTS -> "Playlists"
}

@Composable
fun TolereApp(
    vm: MusicViewModel,
    onPickFolder: () -> Unit,
    onPickIgnoredFolder: () -> Unit = {},
    onExportM3u: (playlistName: String, content: String) -> Unit = { _, _ -> },
    onImportM3u: () -> Unit = {},
    onPickFont: () -> Unit = {},
    onPickUiFont: () -> Unit = {},
    onPickMilkFiles: () -> Unit = {},
    onDeleteTracks: (List<Track>) -> Unit = {},
    onRequestAllFilesPermission: () -> Unit = {},
    onExportBackup: (MusicViewModel.BackupOptions) -> Unit = {},
    onImportBackup: (MusicViewModel.BackupOptions) -> Unit = {},
    openLastFmDashboard: Boolean = false,
    onOpenLastFmDashboardConsumed: () -> Unit = {},
    openNowPlaying: Boolean = false,
    openNowPlayingTrackId: String? = null,
    onOpenNowPlayingConsumed: () -> Unit = {}
) {
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val isScanning by vm.isScanning.collectAsStateWithLifecycle()
    val tab by vm.currentTab.collectAsStateWithLifecycle()
    val filter by vm.filter.collectAsStateWithLifecycle()
    val visible by vm.visibleTracks.collectAsStateWithLifecycle()
    val nowPlaying by vm.nowPlaying.collectAsStateWithLifecycle()
    val isPlaying by vm.isPlaying.collectAsStateWithLifecycle()
    val playbackButtonIsPlaying by vm.playbackButtonIsPlaying.collectAsStateWithLifecycle()
    val artists by vm.artists.collectAsStateWithLifecycle()
    val composers by vm.composers.collectAsStateWithLifecycle()
    val albums by vm.albums.collectAsStateWithLifecycle()
    val genres by vm.genres.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val mostPlayed by vm.mostPlayed.collectAsStateWithLifecycle()
    val sourceFolders by vm.sourceFolders.collectAsStateWithLifecycle()
    val favoriteTracks = remember(playlists, tracks) {
        val favIds = playlists.firstOrNull { it.isFavorites }?.trackIds?.toSet() ?: emptySet()
        tracks.filter { it.id in favIds }
    }
    val scanCount by vm.scanCount.collectAsStateWithLifecycle()
    val queue by vm.queue.collectAsStateWithLifecycle()
    val shuffle by vm.shuffle.collectAsStateWithLifecycle()
    val isSearching by vm.isSearching.collectAsStateWithLifecycle()
    val searchQuery by vm.searchQuery.collectAsStateWithLifecycle()
    val searchResults by vm.searchResults.collectAsStateWithLifecycle()
    val searchArtists by vm.searchArtists.collectAsStateWithLifecycle()
    val searchAlbums by vm.searchAlbums.collectAsStateWithLifecycle()
    val searchGenres by vm.searchGenres.collectAsStateWithLifecycle()
    val themeId by vm.themeId.collectAsStateWithLifecycle()
    val repeatMode by vm.repeatMode.collectAsStateWithLifecycle()
    val lyricsFontPath by vm.lyricsFontPath.collectAsStateWithLifecycle()
    val lyricsTranslationFontPath by vm.lyricsTranslationFontPath.collectAsStateWithLifecycle()
    val lyricsEmphasisFontPath by vm.lyricsEmphasisFontPath.collectAsStateWithLifecycle()
    val uiFontPath by vm.uiFontPath.collectAsStateWithLifecycle()
    val librarySettings by vm.librarySettings.collectAsStateWithLifecycle()
    val allFilesMode by vm.allFilesMode.collectAsStateWithLifecycle()
    // Indexa as fotos de artista uma vez (IO) e converte .url antigos em .jpg
    LaunchedEffect(allFilesMode) {
        withContext(Dispatchers.IO) {
            ArtistMetaStore.rebuildPhotoIndex()
            ArtistMetaStore.migrateLegacyUrlFiles()
        }
    }
    val autoFetchLyrics by vm.autoFetchLyrics.collectAsStateWithLifecycle()
    val shuffleType by vm.shuffleType.collectAsStateWithLifecycle()
    val fadeMs by vm.fadeMs.collectAsStateWithLifecycle()
    val crossfadeMs by vm.crossfadeMs.collectAsStateWithLifecycle()
    val seekBarStyle by vm.seekBarStyle.collectAsStateWithLifecycle()
    val immersiveNowPlaying by vm.immersiveNowPlaying.collectAsStateWithLifecycle()
    val audioOutput by vm.audioOutput.collectAsStateWithLifecycle()
    val glassQuality by vm.glassQuality.collectAsStateWithLifecycle()
    val menuVisualStyle by vm.menuVisualStyle.collectAsStateWithLifecycle()
    val bitPerfect by vm.bitPerfect.collectAsStateWithLifecycle()
    val playCountThreshold by vm.playCountThreshold.collectAsStateWithLifecycle()
    val playCountMinutes by vm.playCountMinutes.collectAsStateWithLifecycle()
    val lastFmUsername by vm.lastFmUsername.collectAsStateWithLifecycle()
    val lastFmSyncMessage by vm.lastFmSyncMessage.collectAsStateWithLifecycle()
    val libraryRootPath by vm.libraryRootPath.collectAsStateWithLifecycle()
    val organizeStatus by vm.organizeStatus.collectAsStateWithLifecycle()
    val milkPresets by vm.milkPresets.collectAsStateWithLifecycle()
    val rootContext = LocalContext.current
    val milkIntervalSec by vm.milkIntervalSec.collectAsStateWithLifecycle()
    val changeSongWithMilkInterval by vm.changeSongWithMilkInterval.collectAsStateWithLifecycle()
    val changePresetOnSongChange by vm.changePresetOnSongChange.collectAsStateWithLifecycle()

    val lyricsFontSize by vm.lyricsFontSize.collectAsStateWithLifecycle()
    val lyricsPrimaryColor by vm.lyricsPrimaryColor.collectAsStateWithLifecycle()
    val lyricsSecondaryColor by vm.lyricsSecondaryColor.collectAsStateWithLifecycle()
    val lyricsBorderColor by vm.lyricsBorderColor.collectAsStateWithLifecycle()
    val lyricsBorderWidth by vm.lyricsBorderWidth.collectAsStateWithLifecycle()
    val lyricsTranslationColor by vm.lyricsTranslationColor.collectAsStateWithLifecycle()
    val lyricsBackingColor by vm.lyricsBackingColor.collectAsStateWithLifecycle()
    val splashEnabled by vm.splashEnabled.collectAsStateWithLifecycle()
    val splashSoundEnabled by vm.splashSoundEnabled.collectAsStateWithLifecycle()
    val floatingIconsEnabled by vm.floatingIconsEnabled.collectAsStateWithLifecycle()
    val homeButtonFontPath by vm.homeButtonFontPath.collectAsStateWithLifecycle()
    val homeButtonColor by vm.homeButtonColor.collectAsStateWithLifecycle()
    val shareFontPath by vm.shareFontPath.collectAsStateWithLifecycle()
    val shareTextColor by vm.shareTextColor.collectAsStateWithLifecycle()
    val shareBgColor by vm.shareBgColor.collectAsStateWithLifecycle()
    val shareBrandColor by vm.shareBrandColor.collectAsStateWithLifecycle()
    val groupSort by vm.groupSort.collectAsStateWithLifecycle()
    val groupOrder by vm.groupOrder.collectAsStateWithLifecycle()
    val trackSort by vm.trackSort.collectAsStateWithLifecycle()
    val trackOrder by vm.trackOrder.collectAsStateWithLifecycle()

    val dynamicDefaultArgb by vm.dynamicDefaultColor.collectAsStateWithLifecycle()
    val dynamicFloatArgb by vm.dynamicFloatColors.collectAsStateWithLifecycle()
    val appColors = rememberAppColors(
        themeId, nowPlaying?.artPath, isPlaying, dynamicDefaultArgb, dynamicFloatArgb
    )
    val layoutScale = rememberLayoutScale()

    val uiFontFamily = remember(uiFontPath) {
        BuiltInFonts.resolveFamily(uiFontPath)
    }

    var showNowPlaying by rememberSaveable { mutableStateOf(false) }
    // Pilha simples para o botão voltar do sistema restaurar a tela anterior
    // (ex.: NowPlaying → Artista → voltar restaura NowPlaying)
    var returnToNowPlaying by remember { mutableStateOf(false) }
    var previousFilter by remember { mutableStateOf<MusicViewModel.Filter?>(null) }
    var showFileManager by remember { mutableStateOf(false) }
    var fileManagerMode by remember { mutableStateOf(FileManagerMode.BROWSE) }
    var fileManagerInitialPath by remember { mutableStateOf<String?>(null) }
    var fileManagerFolderCallback by remember { mutableStateOf<((String) -> Unit)?>(null) }
    var artistsShowComposers by remember { mutableStateOf(false) }
    var pendingOrganizeAction by remember { mutableStateOf<String?>(null) } // "rename" | "move"
    var showOrganizeRenameDialog by remember { mutableStateOf(false) }
    var organizeRenameFolder by remember { mutableStateOf<String?>(null) }
    var settingsPage by rememberSaveable { mutableStateOf(SettingsPage.NONE) }
    var showHelp by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val prefs = rootContext.getSharedPreferences("tolete", android.content.Context.MODE_PRIVATE)
        if (!prefs.getBoolean("help_onboarding_done", false)) {
            showHelp = true
        }
    }

    // Multi-seleção / add-to-playlist state
    var selectedTrackIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showSelectionActions by remember { mutableStateOf(false) }
    var selectionInfoTrack by remember { mutableStateOf<Track?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var lyricsEditTrack by remember { mutableStateOf<Track?>(null) }
    var lyricsEditTarget by remember { mutableStateOf(LyricsEmbedder.Target.EMBEDDED) }
    /** Track pendente do diálogo "abrir .lrc ou tags embutidas". */
    var lyricsSourcePickTrack by remember { mutableStateOf<Track?>(null) }
    var showManageMilkPresets by remember { mutableStateOf(false) }
    var tagEditTrack by remember { mutableStateOf<Track?>(null) }
    var showBatchTagEdit by remember { mutableStateOf(false) }
    var batchTagTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var showBatchRename by remember { mutableStateOf(false) }
    var batchRenameTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var showAddToPlaylist by remember { mutableStateOf(false) }
    var addToPlaylistTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var showCreatePlaylist by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    var createPlaylistInitialTrack by remember { mutableStateOf<Track?>(null) }
    var createPlaylistInitialTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    val selectionMode = selectedTrackIds.isNotEmpty()

    var showLastFm by remember { mutableStateOf(false) }
    LaunchedEffect(openLastFmDashboard) {
        if (openLastFmDashboard) {
            showLastFm = true
            onOpenLastFmDashboardConsumed()
        }
    }
    LaunchedEffect(openNowPlaying, nowPlaying?.id, openNowPlayingTrackId) {
        val currentTrackId = nowPlaying?.id
        if (openNowPlaying && currentTrackId != null &&
            (openNowPlayingTrackId == null || currentTrackId == openNowPlayingTrackId)
        ) {
            showNowPlaying = true
            onOpenNowPlayingConsumed()
        }
    }
    val backdrop = rememberGraphicsLayer()
    var backdropOrigin by remember { mutableStateOf(Offset.Zero) }
    val bottomPadding = if (nowPlaying != null) 190.dp else 110.dp
    var navBarVisible by remember { mutableStateOf(true) }
    val navBarOffsetY by animateDpAsState(
        targetValue = if (navBarVisible) 0.dp else 140.dp,
        animationSpec = tween(280),
        label = "navBar"
    )
    val navScrollConnection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                // Scroll para cima (conteúdo sobe) → esconde; para baixo → mostra
                if (available.y < -6f) navBarVisible = false
                else if (available.y > 6f) navBarVisible = true
                return Offset.Zero
            }
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                // Se ainda sobra scroll para baixo no pós (chegou no topo), mostra a barra
                if (available.y > 0f) navBarVisible = true
                return Offset.Zero
            }
        }
    }
    // Na aba Início o conteúdo não rola o suficiente; garante barra visível
    LaunchedEffect(tab, filter) {
        if (tab == MusicViewModel.Tab.HOME && filter == null) {
            navBarVisible = true
        }
    }

    BackHandler(enabled = selectionMode) { selectedTrackIds = emptySet() }
    BackHandler(enabled = isSearching) { vm.closeSearch() }
    BackHandler(enabled = filter != null && !isSearching) {
        val prev = previousFilter
        if (prev != null) {
            previousFilter = null
            when (prev.tab) {
                MusicViewModel.Tab.ARTISTS -> vm.openArtist(prev.key)
                MusicViewModel.Tab.ALBUMS -> vm.openAlbum(prev.key)
                MusicViewModel.Tab.PLAYLISTS -> vm.openPlaylist(prev.key)
                else -> {
                    vm.clearFilter()
                    if (prev.tab != null) vm.setTab(prev.tab)
                }
            }
        } else if (returnToNowPlaying) {
            returnToNowPlaying = false
            vm.clearFilter()
            showNowPlaying = true
        } else {
            vm.clearFilter()
        }
    }
    BackHandler(enabled = settingsPage != SettingsPage.NONE) {
        settingsPage = when (settingsPage) {
            SettingsPage.FOLDERS -> SettingsPage.LIBRARY
                            SettingsPage.ORGANIZE -> SettingsPage.LIBRARY
            SettingsPage.LYRICS_VIEWER -> SettingsPage.APPEARANCE
            SettingsPage.LIBRARY, SettingsPage.ORGANIZE, SettingsPage.APPEARANCE, SettingsPage.ABOUT, SettingsPage.PLAYER, SettingsPage.BACKUP, SettingsPage.ADVANCED, SettingsPage.VISUALIZER, SettingsPage.SCROBBLE -> SettingsPage.MENU
            SettingsPage.CHANGELOG -> SettingsPage.ABOUT
            SettingsPage.LYRICS_VIEWER -> SettingsPage.APPEARANCE
            else -> SettingsPage.NONE
        }
    }
    BackHandler(enabled = tagEditTrack != null) { tagEditTrack = null }
    BackHandler(enabled = lyricsEditTrack != null) { lyricsEditTrack = null }
    BackHandler(enabled = showHelp) { showHelp = false }
    BackHandler(enabled = showFileManager) { showFileManager = false }
    BackHandler(enabled = showNowPlaying) { showNowPlaying = false }

    fun openAddToPlaylist(tracks: List<Track>) {
        addToPlaylistTracks = tracks
        showAddToPlaylist = true
    }

    // Menus e diálogos leem o tema atual (ou a cor da capa no modo dinâmico) daqui.
    SideEffect { LiveThemeHolder.colors = appColors }
    CompositionLocalProvider(
        LocalUiFontFamily provides uiFontFamily,
        LocalAppColors provides appColors,
        LocalMenuVisualStyle provides menuVisualStyle,
        LocalGlassBackdrop provides backdrop,
        LocalGlassBackdropOrigin provides backdropOrigin
    ) {
    val uiTypography = remember(uiFontFamily) {
        if (uiFontFamily != null) {
            val base = Typography()
            Typography(
                displayLarge = base.displayLarge.copy(fontFamily = uiFontFamily),
                displayMedium = base.displayMedium.copy(fontFamily = uiFontFamily),
                displaySmall = base.displaySmall.copy(fontFamily = uiFontFamily),
                headlineLarge = base.headlineLarge.copy(fontFamily = uiFontFamily),
                headlineMedium = base.headlineMedium.copy(fontFamily = uiFontFamily),
                headlineSmall = base.headlineSmall.copy(fontFamily = uiFontFamily),
                titleLarge = base.titleLarge.copy(fontFamily = uiFontFamily),
                titleMedium = base.titleMedium.copy(fontFamily = uiFontFamily),
                titleSmall = base.titleSmall.copy(fontFamily = uiFontFamily),
                bodyLarge = base.bodyLarge.copy(fontFamily = uiFontFamily),
                bodyMedium = base.bodyMedium.copy(fontFamily = uiFontFamily),
                bodySmall = base.bodySmall.copy(fontFamily = uiFontFamily),
                labelLarge = base.labelLarge.copy(fontFamily = uiFontFamily),
                labelMedium = base.labelMedium.copy(fontFamily = uiFontFamily),
                labelSmall = base.labelSmall.copy(fontFamily = uiFontFamily),
            )
        } else Typography()
    }
    MaterialTheme(
        colorScheme = lightColorScheme(),
        typography = uiTypography
    ) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.Transparent,
        contentColor = Color.White
    ) {
        Box(Modifier.fillMaxSize()) {

            // ---------- Conteúdo ----------
            Box(
                Modifier
                    .fillMaxSize()
                    .onGloballyPositioned { backdropOrigin = it.positionOnScreen() }
                    .drawWithContent {
                        if (GlassConfig.quality == GlassQuality.LIGHT) {
                            // Modo leve: o vidro não lê o fundo, então nem gravamos a camada
                            drawContent()
                        } else {
                            backdrop.record { this@drawWithContent.drawContent() }
                            drawLayer(backdrop)
                        }
                    }
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(rememberFloatingGradient(appColors))
                        .nestedScroll(navScrollConnection)
                ) {
                    // Ícones flutuantes: pausados enquanto o Now Playing cobre a tela (economiza GPU/CPU)
                    if (floatingIconsEnabled && !showNowPlaying) {
                        if (isSearching) {
                            FloatingIconsBackground(kind = "search")
                        } else {
                            val floatTab = when {
                                filter?.tab == MusicViewModel.Tab.ARTISTS -> "artistas"
                                filter?.tab == MusicViewModel.Tab.ALBUMS -> "albuns"
                                tab == MusicViewModel.Tab.HOME -> "inicio"
                                tab == MusicViewModel.Tab.ALL -> "musicas"
                                tab == MusicViewModel.Tab.ARTISTS -> "artistas"
                                tab == MusicViewModel.Tab.ALBUMS -> "albuns"
                                tab == MusicViewModel.Tab.GENRES -> "generos"
                                else -> null
                            }
                            if (floatTab != null) {
                                FloatingIconsBackground(kind = floatTab)
                            }
                        }
                    }
                    Column(Modifier.fillMaxSize().statusBarsPadding()) {
                        if (isSearching) {
                            SearchHeader(
                                query = searchQuery,
                                onQueryChange = vm::setSearchQuery,
                                onClose = vm::closeSearch
                            )
                        } else {
                            Header(
                                title = when {
                                    filter != null && filter!!.tab == MusicViewModel.Tab.PLAYLISTS ->
                                        playlists.firstOrNull { it.id == filter!!.key }?.name ?: filter!!.key
                                    filter != null && filter!!.tab == MusicViewModel.Tab.ALBUMS &&
                                        filter!!.key.startsWith("album-key::") ->
                                        albums.firstOrNull { it.key == filter!!.key.removePrefix("album-key::") }?.name
                                            ?: visible.firstOrNull()?.album.orEmpty()
                                    filter != null -> filter!!.key.removePrefix("composer::")
                                    else -> tabTitle(tab)
                                },
                                showBack = filter != null,
                                onBack = {
                                    val prev = previousFilter
                                    if (prev != null) {
                                        previousFilter = null
                                        when (prev.tab) {
                                            MusicViewModel.Tab.ARTISTS -> vm.openArtist(prev.key)
                                            MusicViewModel.Tab.ALBUMS -> vm.openAlbum(prev.key)
                                            MusicViewModel.Tab.PLAYLISTS -> vm.openPlaylist(prev.key)
                                            else -> {
                                                vm.clearFilter()
                                                if (prev.tab != null) vm.setTab(prev.tab)
                                            }
                                        }
                                    } else if (returnToNowPlaying) {
                                        returnToNowPlaying = false
                                        vm.clearFilter()
                                        showNowPlaying = true
                                    } else {
                                        vm.clearFilter()
                                    }
                                },
                                onOpenSearch = vm::openSearch,
                                onOpenHelp = { showHelp = true },
                                onOpenSettings = { settingsPage = SettingsPage.MENU },
                                onPlayAllShuffled = if (filter == null && !isSearching) {
                                    {
                                        val list = tracks
                                        if (list.isNotEmpty()) vm.playTracks(list.shuffled(), 0)
                                    }
                                } else null,
                                onOpenFileManager = if (filter == null && !isSearching) {
                                    {
                                        fileManagerMode = FileManagerMode.BROWSE
                                        fileManagerInitialPath = null
                                        fileManagerFolderCallback = null
                                        showFileManager = true
                                    }
                                } else null
                            )
                        }

                        Box(
                            Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .pointerInput(tab, filter, isSearching, selectionMode) {
                                    if (selectionMode || isSearching || filter != null) return@pointerInput
                                    val tabs = listOf(
                                        MusicViewModel.Tab.HOME,
                                        MusicViewModel.Tab.ALL,
                                        MusicViewModel.Tab.ARTISTS,
                                        MusicViewModel.Tab.ALBUMS,
                                        MusicViewModel.Tab.GENRES
                                    )
                                    var totalDrag = 0f
                                    detectHorizontalDragGestures(
                                        onDragEnd = {
                                            val threshold = 80f
                                            val idx = tabs.indexOf(tab)
                                            if (totalDrag < -threshold && idx < tabs.lastIndex) {
                                                vm.setTab(tabs[idx + 1])
                                            } else if (totalDrag > threshold && idx > 0) {
                                                vm.setTab(tabs[idx - 1])
                                            }
                                            totalDrag = 0f
                                        },
                                        onHorizontalDrag = { _, dragAmount ->
                                            totalDrag += dragAmount
                                        }
                                    )
                                }
                        ) {
                            val contentKey = when {
                                isSearching -> "search"
                                isScanning && tracks.isEmpty() -> "scanning"
                                tracks.isEmpty() -> "empty"
                                filter != null -> "filter:${filter!!.tab}:${filter!!.key}"
                                else -> "tab:${tab.name}"
                            }
                            val tabOrder = listOf(
                                MusicViewModel.Tab.HOME,
                                MusicViewModel.Tab.ALL,
                                MusicViewModel.Tab.ARTISTS,
                                MusicViewModel.Tab.ALBUMS,
                                MusicViewModel.Tab.GENRES
                            )
                            AnimatedContent(
                                targetState = contentKey,
                                transitionSpec = {
                                    val initialTab = initialState.removePrefix("tab:").let { name ->
                                        tabOrder.firstOrNull { it.name == name }
                                    }
                                    val targetTab = targetState.removePrefix("tab:").let { name ->
                                        tabOrder.firstOrNull { it.name == name }
                                    }
                                    val bothTabs = initialTab != null && targetTab != null
                                    val forward = when {
                                        bothTabs -> tabOrder.indexOf(targetTab) >= tabOrder.indexOf(initialTab)
                                        targetState.startsWith("filter:") && !initialState.startsWith("filter:") -> true
                                        initialState.startsWith("filter:") && !targetState.startsWith("filter:") -> false
                                        targetState == "search" -> true
                                        initialState == "search" -> false
                                        else -> true
                                    }
                                    if (bothTabs || targetState.startsWith("filter:") || initialState.startsWith("filter:")) {
                                        // Animação de "scroll" horizontal entre abas/páginas
                                        if (forward) {
                                            (slideInHorizontally(tween(340, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(200))) togetherWith
                                                (slideOutHorizontally(tween(340, easing = FastOutSlowInEasing)) { -it } + fadeOut(tween(180)))
                                        } else {
                                            (slideInHorizontally(tween(340, easing = FastOutSlowInEasing)) { -it } + fadeIn(tween(200))) togetherWith
                                                (slideOutHorizontally(tween(340, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(180)))
                                        }
                                    } else {
                                        (fadeIn(tween(250)) + slideInVertically(tween(280)) { it / 8 }) togetherWith
                                            (fadeOut(tween(180)) + slideOutVertically(tween(200)) { -it / 8 })
                                    }.using(SizeTransform(clip = false))
                                },
                                label = "mainContent"
                            ) { key ->
                            when {
                                key == "search" || isSearching -> SearchResultsPanel(
                                    tracks = searchResults,
                                    artists = searchArtists,
                                    albums = searchAlbums,
                                    genres = searchGenres,
                                    nowPlayingId = nowPlaying?.id,
                                    bottomPadding = bottomPadding,
                                    selectedIds = selectedTrackIds,
                                    selectionMode = selectionMode,
                                    onTrackClick = { index, track ->
                                        if (selectionMode) {
                                            selectedTrackIds = if (track.id in selectedTrackIds)
                                                selectedTrackIds - track.id else selectedTrackIds + track.id
                                        } else {
                                            vm.playTracks(searchResults, index)
                                        }
                                    },
                                    onTrackLongClick = { track ->
                                        selectedTrackIds = selectedTrackIds + track.id
                                    },
                                    onOpenArtist = { name ->
                                        vm.openArtist(name)
                                    },
                                    onOpenAlbum = { name ->
                                        vm.openAlbum(name)
                                    },
                                    onOpenGenre = { name ->
                                        vm.setTab(MusicViewModel.Tab.GENRES)
                                        vm.openGroup(name)
                                    }
                                )

                                isScanning && tracks.isEmpty() -> Column(
                                    Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    CircularProgressIndicator()
                                    Text("Lendo sua biblioteca… $scanCount", modifier = Modifier.padding(top = 16.dp))
                                }

                                tracks.isEmpty() -> Column(
                                    Modifier.fillMaxSize().padding(32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text("Nenhuma música ainda", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        if (allFilesMode) "Nenhuma faixa encontrada no armazenamento."
                                        else "Ative o acesso a todos os arquivos para escanear suas músicas.",
                                        modifier = Modifier.padding(vertical = 12.dp),
                                        color = Color.White.copy(alpha = 0.7f),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                    if (!allFilesMode) {
                                        Button(onClick = onRequestAllFilesPermission) {
                                            Text("Permitir acesso total")
                                        }
                                    } else {
                                        Button(onClick = { vm.refreshLibrary() }) {
                                            Text("Escanear novamente")
                                        }
                                    }
                                }

                                filter != null && filter!!.tab == MusicViewModel.Tab.ARTISTS -> {
                                    val artistName = filter!!.key.removePrefix("composer::")
                                    val artistTracks = visible
                                    val albumMap = remember(artistTracks) {
                                        artistTracks
                                            .groupBy { it.album.ifBlank { "Álbum desconhecido" } }
                                            .map { (name, ts) ->
                                                val art = ts.firstOrNull { !it.artPath.isNullOrBlank() }?.artPath
                                                val total = ts.sumOf { it.duration }
                                                val year = ts.mapNotNull { it.year }.maxOrNull()
                                                ArtistAlbumItem(name, ts.size, art, total, year)
                                            }
                                    }
                                    ArtistDetailScreen(
                                        artistName = artistName,
                                        trackCount = artistTracks.size,
                                        totalDurationMs = artistTracks.sumOf { it.duration },
                                        albums = albumMap,
                                        tracks = artistTracks,
                                        bottomPadding = bottomPadding,
                                        nowPlayingId = nowPlaying?.id,
                                        accent = appColors.accent,
                                        selectedIds = selectedTrackIds,
                                        selectionMode = selectionMode,
                                        onOpenAlbum = {
                                            previousFilter = filter
                                            returnToNowPlaying = false
                                            vm.openAlbum(it)
                                        },
                                        onPlayAll = { vm.playTracks(artistTracks, 0) },
                                        onShuffle = { vm.playTracks(artistTracks.shuffled(), 0) },
                                        onPlayTracks = { list, index ->
                                            if (selectionMode) {
                                                val track = list.getOrNull(index)
                                                if (track != null) {
                                                    selectedTrackIds = if (track.id in selectedTrackIds)
                                                        selectedTrackIds - track.id else selectedTrackIds + track.id
                                                }
                                            } else {
                                                vm.playTracks(list, index)
                                            }
                                        },
                                        onTrackClick = { index, track ->
                                            if (selectionMode) {
                                                selectedTrackIds = if (track.id in selectedTrackIds)
                                                    selectedTrackIds - track.id else selectedTrackIds + track.id
                                            } else {
                                                vm.playTracks(artistTracks, index)
                                            }
                                        },
                                        onTrackLongClick = { track ->
                                            selectedTrackIds = selectedTrackIds + track.id
                                        },
                                        onRefreshTags = {
                                            vm.forceReloadArtist(artistName) {
                                                android.widget.Toast.makeText(
                                                    rootContext,
                                                    "Tags do artista atualizadas",
                                                    android.widget.Toast.LENGTH_SHORT
                                                ).show()
                                            }
                                        }
                                    )
                                }

                                filter != null && filter!!.tab == MusicViewModel.Tab.ALBUMS -> {
                                    val albumName = if (filter!!.key.startsWith("album-key::")) {
                                        albums.firstOrNull {
                                            it.key == filter!!.key.removePrefix("album-key::")
                                        }?.name ?: visible.firstOrNull()?.album.orEmpty()
                                    } else {
                                        filter!!.key
                                    }
                                    val albumTracks = visible
                                    val art = albumTracks.firstOrNull { !it.artPath.isNullOrBlank() }?.artPath
                                    val artists = remember(albumTracks) {
                                        albumTracks
                                            .flatMap { vm.artistNamesOf(it) }
                                            .distinct()
                                    }
                                    AlbumDetailScreen(
                                        albumName = albumName,
                                        artPath = art,
                                        artists = artists,
                                        tracks = albumTracks,
                                        totalDurationMs = albumTracks.sumOf { it.duration },
                                        nowPlayingId = nowPlaying?.id,
                                        bottomPadding = bottomPadding,
                                        accent = appColors.accent,
                                        selectedIds = selectedTrackIds,
                                        selectionMode = selectionMode,
                                        onPlayAll = { vm.playTracks(albumTracks, 0) },
                                        onShuffle = {
                                            vm.playTracks(albumTracks.shuffled(), 0)
                                        },
                                        onOpenArtist = { name ->
                                            previousFilter = filter
                                            returnToNowPlaying = false
                                            vm.openArtist(name)
                                        },
                                        onTrackClick = { index, track ->
                                            if (selectionMode) {
                                                selectedTrackIds = if (track.id in selectedTrackIds)
                                                    selectedTrackIds - track.id else selectedTrackIds + track.id
                                            } else {
                                                vm.playTracks(albumTracks, index)
                                            }
                                        },
                                        onTrackLongClick = { track ->
                                            selectedTrackIds = selectedTrackIds + track.id
                                        },
                                        onRefreshTags = {
                                            vm.forceReloadAlbum(albumName) {
                                                android.widget.Toast.makeText(
                                                    rootContext,
                                                    "Tags do álbum atualizadas",
                                                    android.widget.Toast.LENGTH_SHORT
                                                ).show()
                                            }
                                        }
                                    )
                                }

                                filter != null && filter!!.tab == MusicViewModel.Tab.PLAYLISTS -> {
                                    val plId = filter!!.key
                                    val pl = playlists.firstOrNull { it.id == plId }
                                    PlaylistTracksScreen(
                                        playlist = pl,
                                        tracks = visible,
                                        nowPlayingId = nowPlaying?.id,
                                        bottomPadding = bottomPadding,
                                        accent = appColors.accent,
                                        selectedIds = selectedTrackIds,
                                        selectionMode = selectionMode,
                                        onPlayAll = { if (visible.isNotEmpty()) vm.playTracks(visible, 0) },
                                        onShuffle = { if (visible.isNotEmpty()) vm.playTracks(visible.shuffled(), 0) },
                                        onTrackClick = { index, track ->
                                            if (selectionMode) {
                                                selectedTrackIds = if (track.id in selectedTrackIds)
                                                    selectedTrackIds - track.id else selectedTrackIds + track.id
                                            } else {
                                                vm.playTracks(visible, index)
                                            }
                                        },
                                        onTrackLongClick = { track ->
                                            selectedTrackIds = selectedTrackIds + track.id
                                        },
                                        onReorder = { ids -> vm.reorderPlaylistTracks(plId, ids) },
                                        onRemove = { trackId -> vm.removeFromPlaylist(plId, trackId) }
                                    )
                                }

                                filter != null || tab == MusicViewModel.Tab.ALL -> {
                                    val listTracks = if (filter == null && tab == MusicViewModel.Tab.ALL) {
                                        vm.sortedTracks(visible)
                                    } else visible
                                    Column(Modifier.fillMaxSize()) {
                                        if (filter == null && tab == MusicViewModel.Tab.ALL) {
                                            Row(
                                                Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(Modifier.weight(1f)) {
                                                    SortBar(
                                                        isGroup = false,
                                                        groupSort = groupSort,
                                                        groupOrder = groupOrder,
                                                        trackSort = trackSort,
                                                        trackOrder = trackOrder,
                                                        onGroupSort = { s, o -> vm.setGroupSort(s, o) },
                                                        onTrackSort = { s, o -> vm.setTrackSort(s, o) }
                                                    )
                                                }
                                                IconButton(
                                                    onClick = {
                                                        val all = listTracks
                                                        if (all.isNotEmpty()) {
                                                            val shuffled = all.shuffled()
                                                            vm.playTracks(shuffled, 0)
                                                        }
                                                    }
                                                ) {
                                                    Icon(
                                                        Icons.Rounded.Shuffle,
                                                        contentDescription = "Embaralhar todas e tocar",
                                                        tint = appColors.accent
                                                    )
                                                }
                                            }
                                        }
                                        TrackList(
                                            tracks = listTracks,
                                            nowPlayingId = nowPlaying?.id,
                                            bottomPadding = bottomPadding,
                                            showTrackNumbers = filter != null && tab == MusicViewModel.Tab.ALBUMS,
                                            selectedIds = selectedTrackIds,
                                            selectionMode = selectionMode,
                                            onClick = { index, track ->
                                                if (selectionMode) {
                                                    selectedTrackIds = if (track.id in selectedTrackIds)
                                                        selectedTrackIds - track.id else selectedTrackIds + track.id
                                                } else {
                                                    vm.playTracks(listTracks, index)
                                                }
                                            },
                                            onLongClick = { track ->
                                                selectedTrackIds = selectedTrackIds + track.id
                                            }
                                        )
                                    }
                                }

                                tab == MusicViewModel.Tab.HOME -> {
                                    LysPlaceHome(
                                        mostPlayed = mostPlayed,
                                        history = history,
                                        favorites = favoriteTracks,
                                        playlists = playlists,
                                        bottomPadding = bottomPadding,
                                        onPlayTracks = { list, idx -> vm.playTracks(list, idx) },
                                        onOpenPlaylist = { vm.openPlaylist(it) },
                                        onOpenFavorites = { /* favoritas via filtro ou lista */ },
                                        onCreatePlaylist = {
                                            createPlaylistInitialTrack = null; createPlaylistInitialTracks = emptyList()
                                            newPlaylistName = ""
                                            showCreatePlaylist = true
                                        },
                                        onImportPlaylist = onImportM3u,
                                        onExportPlaylist = { pl ->
                                            vm.exportPlaylistM3u(pl.id)?.let { onExportM3u(pl.name, it) }
                                        },
                                        onDeletePlaylist = { pl -> vm.deletePlaylist(pl.id) },
                                        onReorderPlaylists = { ids -> vm.reorderPlaylists(ids) },
                                        playCountOf = vm::playCountOf,
                                        appColors = appColors,
                                        homeButtonFontPath = homeButtonFontPath,
                                        homeButtonColor = homeButtonColor,
                                        selectedIds = selectedTrackIds,
                                        selectionMode = selectionMode,
                                        onTrackClick = { list, index, track ->
                                            if (selectionMode) {
                                                selectedTrackIds = if (track.id in selectedTrackIds)
                                                    selectedTrackIds - track.id else selectedTrackIds + track.id
                                            } else {
                                                vm.playTracks(list, index)
                                            }
                                        },
                                        onTrackLongClick = { track ->
                                            selectedTrackIds = selectedTrackIds + track.id
                                        },
                                        mostPlayedRanked = { kind, period -> vm.mostPlayedRanked(kind, period) },
                                        historyInPeriod = { period -> vm.historyInPeriod(period) },
                                        onExportTopStats = { kind, period, items ->
                                            TopStatsShareHelper.share(
                                                context = rootContext,
                                                kind = kind,
                                                period = period,
                                                items = items
                                            )
                                        },
                                        periodPlayCount = vm::playCountTotal,
                                        onOpenLastFm = { showLastFm = true }
                                    )
                                }

                                else -> {
                                    val groups = when (tab) {
                                        MusicViewModel.Tab.ARTISTS -> {
                                            val src = if (artistsShowComposers) composers else artists
                                            // Observa o índice de fotos (em memória) para recompor quando mudar
                                            @Suppress("UNUSED_VARIABLE")
                                            val photoVersion = ArtistMetaStore.photoVersion.collectAsStateWithLifecycle().value
                                            vm.sortedArtists(src).map { artist ->
                                                val metaImg = ArtistMetaStore.cachedPhotoPath(artist.name)
                                                val art = metaImg ?: artist.artPath
                                                val key = if (artistsShowComposers) "composer::${artist.name}" else artist.name
                                                GroupItem(artist.name, faixas(artist.trackCount), key, art, round = true)
                                            }
                                        }
                                        MusicViewModel.Tab.ALBUMS -> vm.sortedAlbums(albums).map {
                                            GroupItem(
                                                it.name,
                                                "${it.artist} · ${faixas(it.trackCount)}",
                                                "album-key::${it.key}",
                                                it.artPath
                                            )
                                        }
                                        MusicViewModel.Tab.GENRES -> vm.sortedGenres(genres).map {
                                            GroupItem(it.name, faixas(it.trackCount), it.name, it.artPath)
                                        }
                                        else -> emptyList()
                                    }
                                    Column(Modifier.fillMaxSize()) {
                                        Row(
                                            Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 16.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(Modifier.weight(1f)) {
                                                SortBar(
                                                    isGroup = true,
                                                    groupSort = groupSort,
                                                    groupOrder = groupOrder,
                                                    trackSort = trackSort,
                                                    trackOrder = trackOrder,
                                                    onGroupSort = { s, o -> vm.setGroupSort(s, o) },
                                                    onTrackSort = { s, o -> vm.setTrackSort(s, o) },
                                                    compact = true
                                                )
                                            }
                                            if (tab == MusicViewModel.Tab.ARTISTS) {
                                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    listOf(false to "Artistas", true to "Compositores").forEach { (comp, label) ->
                                                        val sel = artistsShowComposers == comp
                                                        Text(
                                                            label,
                                                            color = if (sel) Color.Black else Color.White.copy(0.85f),
                                                            fontSize = 12.sp,
                                                            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                                                            modifier = Modifier
                                                                .clip(RoundedCornerShape(20.dp))
                                                                .background(if (sel) appColors.accent else Color.White.copy(0.12f))
                                                                .clickable { artistsShowComposers = comp }
                                                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                        GroupList(groups, bottomPadding, onClick = vm::openGroup)
                                    }
                                }
                            }
                            } // AnimatedContent
                            if (isScanning && tracks.isNotEmpty()) {
                                LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
                            }
                        }
                    }
                }
            }

            // ---------- Barras de vidro flutuantes ----------
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 10.dp)
                    .offset(y = navBarOffsetY),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                nowPlaying?.let {
                    MiniPlayer(
                        track = it,
                        isPlaying = isPlaying,
                        backdrop = backdrop,
                        onClick = { showNowPlaying = true },
                        onPrevious = vm::previous,
                        onToggle = vm::togglePlayPause,
                        onNext = vm::next
                    )
                }

                LiquidGlassNavigation(
                    currentTab = tab,
                    onTabSelected = { t ->
                        previousFilter = null
                        returnToNowPlaying = false
                        vm.setTab(t)
                    },
                    backdrop = backdrop
                )
            }

            // ---------- Dashboard do Last.fm ----------
            AnimatedVisibility(
                visible = showLastFm,
                enter = slideInHorizontally(tween(300)) { it } + fadeIn(tween(220)),
                exit = slideOutHorizontally(tween(260)) { it } + fadeOut(tween(180))
            ) {
                LastFmDashboardScreen(
                    tracks = tracks,
                    appColors = appColors,
                    onBack = { showLastFm = false }
                )
            }

            // ---------- Configurações ----------
            AnimatedVisibility(
                visible = settingsPage != SettingsPage.NONE,
                enter = slideInHorizontally(tween(300)) { it } + fadeIn(tween(220)),
                exit = slideOutHorizontally(tween(260)) { it } + fadeOut(tween(180))
            ) {
                SettingsScreen(
                    page = settingsPage,
                    folders = sourceFolders,
                    totalTracks = tracks.size,
                    isScanning = isScanning,
                    scanCount = scanCount,
                    themeId = themeId,
                    lyricsFontPath = lyricsFontPath,
                    lyricsTranslationFontPath = lyricsTranslationFontPath,
                    lyricsEmphasisFontPath = lyricsEmphasisFontPath,
                    uiFontPath = uiFontPath,
                    librarySettings = librarySettings,
                    appColors = appColors,
                    onNavigate = { settingsPage = it },
                    onBack = {
                        settingsPage = when (settingsPage) {
                            SettingsPage.FOLDERS -> SettingsPage.LIBRARY
                            SettingsPage.ORGANIZE -> SettingsPage.LIBRARY
                            SettingsPage.LYRICS_VIEWER -> SettingsPage.APPEARANCE
                            SettingsPage.CHANGELOG, SettingsPage.LICENSES, SettingsPage.FONT_CREDITS -> SettingsPage.ABOUT
                            SettingsPage.LIBRARY, SettingsPage.APPEARANCE,
                            SettingsPage.ABOUT, SettingsPage.PLAYER, SettingsPage.BACKUP, SettingsPage.SCROBBLE -> SettingsPage.MENU
                            else -> SettingsPage.NONE
                        }
                    },
                    onAddFolder = {
                        fileManagerMode = FileManagerMode.PICK_FOLDER
                        fileManagerInitialPath = null
                        fileManagerFolderCallback = { path ->
                            // Pastas de biblioteca: guarda path file://
                            vm.addFolderPath(path)
                        }
                        showFileManager = true
                    },
                    onRemoveFolder = vm::removeFolder,
                    onRefresh = vm::refreshLibrary,
                    onThemeSelected = vm::setThemeId,
                    menuVisualStyle = menuVisualStyle,
                    onMenuVisualStyleChange = vm::setMenuVisualStyle,
                    dynamicDefaultColor = dynamicDefaultArgb,
                    onDynamicDefaultColorChange = vm::setDynamicDefaultColor,
                    dynamicFloatColors = dynamicFloatArgb,
                    onDynamicFloatColorsChange = vm::setDynamicFloatColors,
                    onPickFont = { vm.beginFontPickForLyrics(); onPickFont() },
                    onClearFont = { vm.setLyricsFontPath(null) },
                    onPickUiFont = onPickUiFont,
                    onClearUiFont = { vm.setUiFontPath(null) },
                    onSelectUiFont = { key -> vm.setUiFontPath(key) },
                    onSelectLyricsFont = { key -> vm.setLyricsFontPath(key) },
                    onPickTranslationFont = {
                        // Reusa o picker de fonte: marca destino e abre o mesmo fluxo
                        vm.beginFontPickForTranslation()
                        onPickFont()
                    },
                    onClearTranslationFont = { vm.setLyricsTranslationFontPath(null) },
                    onSelectTranslationFont = { key -> vm.setLyricsTranslationFontPath(key) },
                    onSelectLyricsEmphasisFont = vm::setLyricsEmphasisFontPath,
                    onSplitArtistsChange = vm::setSplitArtists,
                    onArtistSeparatorsChange = vm::setArtistSeparators,
                    onArtistExceptionsChange = vm::setArtistExceptions,
                    onSplitGenresChange = vm::setSplitGenres,
                    onGenreSeparatorsChange = vm::setGenreSeparators,
                    onIgnoredFoldersChange = vm::setIgnoredFolders,
                    onPickIgnoredFolder = {
                        fileManagerMode = FileManagerMode.PICK_FOLDER
                        fileManagerInitialPath = null
                        fileManagerFolderCallback = { path ->
                            val label = path.removePrefix("/storage/emulated/0/").trim('/')
                            val current = vm.librarySettings.value.ignoredFolders
                            val lines = current.split("\n").map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
                            if (lines.none { it.equals(label, ignoreCase = true) }) {
                                lines.add(label)
                                vm.setIgnoredFolders(lines.joinToString("\n"))
                            }
                        }
                        showFileManager = true
                    },
                    onMinDurationSecChange = vm::setMinDurationSec,
                    allFilesMode = allFilesMode,
                    onAllFilesModeChange = vm::setAllFilesMode,
                    onRequestAllFilesPermission = onRequestAllFilesPermission,
                    autoFetchLyrics = autoFetchLyrics,
                    onAutoFetchLyricsChange = vm::setAutoFetchLyrics,
                    shuffleType = shuffleType,
                    onShuffleTypeChange = vm::setShuffleType,
                    fadeMs = fadeMs,
                    onFadeMsChange = vm::setFadeMs,
                    crossfadeMs = crossfadeMs,
                    onCrossfadeMsChange = vm::setCrossfadeMs,
                    seekBarStyle = seekBarStyle,
                    onSeekBarStyleChange = vm::setSeekBarStyle,
                    immersiveNowPlaying = immersiveNowPlaying,
                    onImmersiveNowPlayingChange = vm::setImmersiveNowPlaying,
                    audioOutput = audioOutput,
                    onAudioOutputChange = { vm.setAudioOutput(it, applyNow = true) },
                    bitPerfect = bitPerfect,
                    onBitPerfectChange = { vm.setBitPerfect(it, applyNow = true) },
                    playCountThreshold = playCountThreshold,
                    onPlayCountThresholdChange = vm::setPlayCountThreshold,
                    playCountMinutes = playCountMinutes,
                    onPlayCountMinutesChange = vm::setPlayCountMinutes,
                    lastFmUsername = lastFmUsername,
                    onLastFmUsernameChange = vm::setLastFmUsername,
                    lastFmSyncMessage = lastFmSyncMessage,
                    onSyncLastFm = vm::syncFromLastFm,
                    onClearPlaybackHistory = vm::clearPlaybackHistory,
                    onClearFavorites = vm::clearFavorites,
                    libraryRootPath = libraryRootPath,
                    onPickLibraryRoot = {
                        fileManagerMode = FileManagerMode.PICK_FOLDER
                        fileManagerInitialPath = libraryRootPath
                        fileManagerFolderCallback = { path -> vm.setLibraryRootPath(path) }
                        showFileManager = true
                    },
                    onBulkRenameByTags = {
                        pendingOrganizeAction = "rename"
                        fileManagerMode = FileManagerMode.PICK_FOLDER
                        fileManagerInitialPath = null
                        fileManagerFolderCallback = { path ->
                            organizeRenameFolder = path
                            showOrganizeRenameDialog = true
                        }
                        showFileManager = true
                    },
                    onMoveToLibraryRoot = {
                        pendingOrganizeAction = "move"
                        fileManagerMode = FileManagerMode.PICK_FOLDER
                        fileManagerInitialPath = null
                        fileManagerFolderCallback = { path ->
                            vm.moveFolderToLibraryRoot(path)
                        }
                        showFileManager = true
                    },
                    organizeStatus = organizeStatus,
                    milkPresetCount = milkPresets.size,
                    milkIntervalSec = milkIntervalSec,
                    onPickMilkFiles = onPickMilkFiles,
                    onClearMilkPresets = vm::clearMilkPresets,
                    onMilkIntervalChange = vm::setMilkIntervalSec,
                    changeSongWithInterval = changeSongWithMilkInterval,
                    onChangeSongWithIntervalChange = vm::setChangeSongWithMilkInterval,
                    changePresetOnSongChange = changePresetOnSongChange,
                    onChangePresetOnSongChange = vm::setChangePresetOnSongChange,
                    onManageMilkPresets = { showManageMilkPresets = true },
                    onOpenRecommendedPresets = {
                        val intent = android.content.Intent(
                            android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse("https://github.com/projectM-visualizer/presets-cream-of-the-crop")
                        )
                        rootContext.startActivity(intent)
                    },
                    lyricsFontSize = lyricsFontSize,
                    onLyricsFontSizeChange = vm::setLyricsFontSize,
                    lyricsPrimaryColor = lyricsPrimaryColor,
                    onLyricsPrimaryColorChange = vm::setLyricsPrimaryColor,
                    lyricsSecondaryColor = lyricsSecondaryColor,
                    onLyricsSecondaryColorChange = vm::setLyricsSecondaryColor,
                    lyricsBorderColor = lyricsBorderColor,
                    onLyricsBorderColorChange = vm::setLyricsBorderColor,
                    lyricsBorderWidth = lyricsBorderWidth,
                    onLyricsBorderWidthChange = vm::setLyricsBorderWidth,
                    lyricsTranslationColor = lyricsTranslationColor,
                    onLyricsTranslationColorChange = vm::setLyricsTranslationColor,
                    lyricsBackingColor = lyricsBackingColor,
                    onLyricsBackingColorChange = vm::setLyricsBackingColor,
                    onExportBackup = onExportBackup,
                    onImportBackup = onImportBackup,
                    splashEnabled = splashEnabled,
                    onSplashEnabledChange = vm::setSplashEnabled,
                    splashSoundEnabled = splashSoundEnabled,
                    onSplashSoundChange = vm::setSplashSoundEnabled,
                    floatingIconsEnabled = floatingIconsEnabled,
                    onFloatingIconsChange = vm::setFloatingIconsEnabled,
                    glassQuality = glassQuality,
                    onGlassQualityChange = vm::setGlassQuality,
                    homeButtonFontPath = homeButtonFontPath,
                    onHomeButtonFontSelect = vm::setHomeButtonFontPath,
                    homeButtonColor = homeButtonColor,
                    onHomeButtonColorChange = vm::setHomeButtonColor,
                    shareFontPath = shareFontPath,
                    onShareFontSelect = vm::setShareFontPath,
                    shareTextColor = shareTextColor,
                    onShareTextColorChange = vm::setShareTextColor,
                    shareBgColor = shareBgColor,
                    onShareBgColorChange = vm::setShareBgColor,
                    shareBrandColor = shareBrandColor,
                    onShareBrandColorChange = vm::setShareBrandColor,
                    onPickDataFolder = {
                        fileManagerMode = FileManagerMode.PICK_FOLDER
                        fileManagerInitialPath = com.tolete.player.data.LyronStorage.getCustomRootPath()
                            ?: "/storage/emulated/0"
                        fileManagerFolderCallback = { path ->
                            com.tolete.player.data.LyronStorage.setMode(
                                rootContext,
                                com.tolete.player.data.LyronStorage.Mode.CUSTOM,
                                path
                            )
                        }
                        showFileManager = true
                    }
                )
            }

            AnimatedVisibility(
                visible = tagEditTrack != null,
                enter = slideInVertically(tween(300)) { it } + fadeIn(tween(220)),
                exit = slideOutVertically(tween(260)) { it } + fadeOut(tween(180))
            ) {
                tagEditTrack?.let { track ->
                    val editCtx = LocalContext.current
                    TagEditorScreen(
                        track = track,
                        appColors = appColors,
                        onClose = { tagEditTrack = null },
                        onSave = { edits ->
                            vm.updateTrackTags(
                                trackId = track.id,
                                fields = edits.toWriterFields()
                            ) { ok, msg ->
                                android.widget.Toast.makeText(editCtx, msg, android.widget.Toast.LENGTH_SHORT).show()
                                if (ok) tagEditTrack = null
                            }
                        },
                        isPlaying = isPlaying,
                        getPosition = vm::currentPosition,
                        onSeek = vm::seekTo,
                        onToggle = vm::togglePlayPause
                    )
                }
            }

            if (showHelp) {
                HelpScreen(
                    onClose = { showHelp = false },
                    onFinishedFirstRun = {
                        rootContext.getSharedPreferences("tolete", android.content.Context.MODE_PRIVATE)
                            .edit().putBoolean("help_onboarding_done", true).apply()
                    }
                )
            }

            // Diálogo: escolher fonte da letra antes de abrir o editor
            lyricsSourcePickTrack?.let { pickTrack ->
                val hasLrc = remember(pickTrack.id) { LyricsEmbedder.hasExternalLrc(pickTrack) }
                AppAlertDialog(
                    onDismissRequest = { lyricsSourcePickTrack = null },
                    title = { Text("Editar letra") },
                    text = {
                        Text(
                            if (hasLrc)
                                "Qual fonte de letra deseja abrir?\n\n• Arquivo .lrc — ao lado da música (salva de volta no .lrc)\n• Tags embutidas — dentro do arquivo de áudio (salva nas tags)"
                            else
                                "Não há arquivo .lrc ao lado desta música.\nAbrir as tags embutidas do arquivo?"
                        )
                    },
                    confirmButton = {
                        Column {
                            if (hasLrc) {
                                TextButton(
                                    onClick = {
                                        lyricsEditTarget = LyricsEmbedder.Target.LRC_FILE
                                        lyricsEditTrack = pickTrack
                                        lyricsSourcePickTrack = null
                                        showNowPlaying = false
                                    }
                                ) { Text("Arquivo .lrc") }
                            }
                            TextButton(
                                onClick = {
                                    lyricsEditTarget = LyricsEmbedder.Target.EMBEDDED
                                    lyricsEditTrack = pickTrack
                                    lyricsSourcePickTrack = null
                                    showNowPlaying = false
                                }
                            ) { Text(if (hasLrc) "Tags embutidas" else "Abrir tags embutidas") }
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { lyricsSourcePickTrack = null }) {
                            Text("Cancelar")
                        }
                    }
                )
            }

            AnimatedVisibility(
                visible = lyricsEditTrack != null,
                enter = slideInVertically(tween(300)) { it } + fadeIn(tween(220)),
                exit = slideOutVertically(tween(260)) { it } + fadeOut(tween(180))
            ) {
                lyricsEditTrack?.let { track ->
                    val editCtx = LocalContext.current
                    val target = lyricsEditTarget
                    // Carrega a fonte escolhida ANTES de montar o editor.
                    // LyricsEditorScreen usa remember { initialLines } e não reage a updates assíncronos.
                    var loadedLines by remember(track.id, target) { mutableStateOf<List<LyricLine>?>(null) }
                    LaunchedEffect(track.id, target) {
                        loadedLines = null
                        val fromSource = when (target) {
                            LyricsEmbedder.Target.LRC_FILE -> vm.loadExternalLyrics(track)
                            LyricsEmbedder.Target.EMBEDDED -> vm.loadEmbeddedLyrics(track)
                        }
                        // Se a fonte escolhida está vazia mas o player mostra uma letra (vinda de
                        // .elrc/.ttml, de outra tag ou da busca online), abre o editor com ela em vez
                        // de um editor em branco — salvar em branco parecia "apagar" a letra.
                        loadedLines = if (fromSource.isNotEmpty()) fromSource
                        else try { vm.loadLyrics(track) } catch (_: Exception) { emptyList() }
                    }
                    if (loadedLines == null) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(0.9f)),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = appColors.accent)
                        }
                    } else {
                        // key força recomposição limpa quando a fonte/letra muda
                        key(track.id, target, loadedLines!!.size) {
                            LyricsEditorScreen(
                                track = track,
                                initialLines = loadedLines!!,
                                isPlaying = isPlaying,
                                getPosition = vm::currentPosition,
                                onSeek = vm::seekTo,
                                onToggle = vm::togglePlayPause,
                                onSave = { lines, saveTarget ->
                                    val ok = vm.saveSyncedLyrics(track, lines, saveTarget)
                                    val msg = when {
                                        ok && saveTarget == LyricsEmbedder.Target.LRC_FILE -> "Letra salva no arquivo .lrc"
                                        ok && saveTarget == LyricsEmbedder.Target.EMBEDDED -> "Letra salva nas tags do arquivo"
                                        saveTarget == LyricsEmbedder.Target.LRC_FILE -> "Falha ao salvar .lrc (ative Acesso a todos os arquivos)"
                                        else -> "Falha ao salvar letra nas tags"
                                    }
                                    android.widget.Toast.makeText(editCtx, msg, android.widget.Toast.LENGTH_SHORT).show()
                                    if (ok) {
                                        vm.setPlaybackSpeed(1f)
                                        lyricsEditTrack = null
                                    }
                                },
                                onClose = {
                                    vm.setPlaybackSpeed(1f)
                                    lyricsEditTrack = null
                                },
                                appColors = appColors,
                                initialTarget = target,
                                getPlaybackSpeed = vm::currentPlaybackSpeed,
                                onPlaybackSpeed = vm::setPlaybackSpeed
                            )
                        }
                    }
                }
            }

            // ---------- Tocando agora ----------
            if (showManageMilkPresets) {
                MilkPresetPickerDialog(
                    presets = milkPresets,
                    currentPath = null,
                    onDismiss = { showManageMilkPresets = false },
                    onSelect = { },
                    onDelete = { path -> vm.deleteMilkPreset(path) },
                    manageMode = true
                )
            }

            AnimatedVisibility(
                visible = showNowPlaying && nowPlaying != null,
                enter = slideInVertically(tween(320)) { it } + fadeIn(tween(240)),
                exit = slideOutVertically(tween(280)) { it } + fadeOut(tween(200))
            ) {
                nowPlaying?.let { current ->
                    // Deriva de playlists (StateFlow) para recompor imediatamente ao favoritar
                    val isFavorite = playlists
                        .firstOrNull { it.isFavorites }
                        ?.trackIds
                        ?.contains(current.id) == true
                    val playerDur by vm.durationMs.collectAsStateWithLifecycle()
                    NowPlayingScreen(
                        track = current,
                        isPlaying = isPlaying,
                        playButtonIsPlaying = playbackButtonIsPlaying,
                        shuffle = shuffle,
                        repeatMode = repeatMode,
                        queue = queue,
                        isFavorite = isFavorite,
                        lyricsFontPath = lyricsFontPath,
                        lyricsTranslationFontPath = lyricsTranslationFontPath,
                        lyricsEmphasisFontPath = lyricsEmphasisFontPath,
                        highQualityOutput = audioOutput == MusicViewModel.AudioOutputBackend.HIGH_QUALITY,
                        getPosition = vm::currentPosition,
                        playerDurationMs = playerDur,
                        onClose = { showNowPlaying = false },
                        onPrevious = vm::previous,
                        onToggle = vm::togglePlayPause,
                        onNext = vm::next,
                        onSeek = vm::seekTo,
                        getPlaybackSpeed = vm::currentPlaybackSpeed,
                        onPlaybackSpeed = vm::setPlaybackSpeed,
                        onToggleShuffle = vm::toggleShuffle,
                        onCycleRepeat = vm::cycleRepeatMode,
                        onSkipToQueueItem = vm::skipToQueueItem,
                        onMoveQueueItem = vm::moveQueueItem,
                        onRemoveFromQueue = vm::removeFromQueue,
                        onToggleFavoriteTrack = { t -> vm.toggleFavorite(t.id) },
                        onDeleteTrack = { t -> onDeleteTracks(listOf(t)) },
                        onPlayNextFromQueue = { t -> vm.playNext(t) },
                        isFavoriteCheck = { id -> vm.isFavorite(id) },
                        onToggleFavorite = { vm.toggleFavorite(current.id) },
                        onAddToPlaylist = { openAddToPlaylist(listOf(current)) },
                        onAddToBlacklist = {
                            vm.addToTrackBlacklist(current)
                        },
                        onEditTags = {
                            tagEditTrack = current
                            showNowPlaying = false
                        },
                        onEditLyrics = {
                            lyricsSourcePickTrack = current
                        },
                        artistNames = remember(current.artist, librarySettings) { vm.artistNamesOf(current) },
                        onOpenArtist = { name ->
                            returnToNowPlaying = true
                            previousFilter = null
                            showNowPlaying = false
                            vm.openArtist(name)
                        },
                        onOpenAlbum = {
                            returnToNowPlaying = true
                            previousFilter = null
                            showNowPlaying = false
                            vm.openAlbum(current.album)
                        },
                        loadLyrics = { vm.loadLyrics(current) },
                        searchLyrics = { t, a -> vm.searchLyrics(t, a) },
                        embedLyricsResult = { r, target -> vm.embedLyricsResult(current, r, target) },
                        appColors = appColors,
                        milkPresets = milkPresets,
                        onDeletePreset = { path -> vm.deleteMilkPreset(path) },
                        milkIntervalSec = milkIntervalSec,
                        changeSongWithMilkInterval = changeSongWithMilkInterval,
                        changePresetOnSongChange = changePresetOnSongChange,
                        onSkipToRandom = {
                            val q = vm.queue.value
                            val curId = vm.nowPlaying.value?.id
                            if (q.size > 1) {
                                val others = q.indices.filter { q[it].id != curId }
                                val idx = others.randomOrNull() ?: q.indices.random()
                                vm.skipToQueueItem(idx)
                            } else {
                                vm.next()
                            }
                        },
                        lyricsFontSize = lyricsFontSize,
                        lyricsPrimaryColor = lyricsPrimaryColor,
                        lyricsSecondaryColor = lyricsSecondaryColor,
                        lyricsBorderColor = lyricsBorderColor,
                        lyricsBorderWidth = lyricsBorderWidth,
                        lyricsTranslationColor = lyricsTranslationColor,
                        lyricsBackingColor = lyricsBackingColor,
                        playCount = vm.playCountOf(current.id),
                        firstPlayedAt = vm.firstPlayedAtOf(current.id).takeIf { it > 0L },
                        lastPlayedAt = vm.lastPlayedAt(current.id),
                        seekBarStyle = seekBarStyle,
                        immersiveNowPlaying = immersiveNowPlaying,
                        onOpenContainingFolder = {
                            val path = current.path
                            if (path.isNotBlank()) {
                                fileManagerMode = FileManagerMode.BROWSE
                                fileManagerInitialPath = path
                                fileManagerFolderCallback = null
                                showNowPlaying = false
                                showFileManager = true
                            }
                        }
                    )
                }
            }

            // ---------- FAB de multi-seleção ----------
            if (selectionMode) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(bottom = bottomPadding + 16.dp, end = 20.dp),
                    contentAlignment = Alignment.BottomEnd
                ) {
                    GlassSurface(
                        backdrop = backdrop,
                        shape = CircleShape,
                        style = GlassStyle.Lens,
                        modifier = Modifier
                            .size(56.dp)
                            .clickable { showSelectionActions = true }
                    ) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                "${selectedTrackIds.size}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            if (showSelectionActions && selectionMode) {
                // Inclui listas da Home (favoritas, histórico, mais tocadas) além da lista visível
                val pool = remember(isSearching, searchResults, visible, favoriteTracks, history, mostPlayed, tracks) {
                    if (isSearching) searchResults
                    else (visible + favoriteTracks + history + mostPlayed + tracks).distinctBy { it.id }
                }
                // Na ordem em que foram selecionadas (selectedTrackIds preserva a ordem de inserção)
                val selectedTracks = remember(selectedTrackIds, pool) {
                    val byId = pool.associateBy { it.id }
                    selectedTrackIds.mapNotNull { byId[it] }
                }
                val shareCtx = LocalContext.current
                SelectionActionsMenu(
                    count = selectedTracks.size,
                    backdrop = backdrop,
                    onDismiss = { showSelectionActions = false },
                    onClearSelection = {
                        showSelectionActions = false
                        selectedTrackIds = emptySet()
                    },
                    onSelectAll = {
                        val favIds = favoriteTracks.map { it.id }.toSet()
                        val histIds = history.map { it.id }.toSet()
                        val mostIds = mostPlayed.map { it.id }.toSet()
                        val candidates = when {
                            isSearching -> searchResults
                            selectedTrackIds.isNotEmpty() && selectedTrackIds.all { it in favIds } -> favoriteTracks
                            selectedTrackIds.isNotEmpty() && selectedTrackIds.all { it in histIds } -> history
                            selectedTrackIds.isNotEmpty() && selectedTrackIds.all { it in mostIds } -> mostPlayed
                            else -> visible
                        }
                        selectedTrackIds = candidates.map { it.id }.toSet()
                    },
                    onPlayNext = {
                        vm.playNextAll(selectedTracks)
                        showSelectionActions = false
                        selectedTrackIds = emptySet()
                    },
                    onPlayLast = {
                        vm.playLastAll(selectedTracks)
                        showSelectionActions = false
                        selectedTrackIds = emptySet()
                    },
                    onAddToPlaylist = {
                        showSelectionActions = false
                        openAddToPlaylist(selectedTracks)
                    },
                    onFavorite = {
                        selectedTracks.forEach { vm.toggleFavorite(it.id) }
                        showSelectionActions = false
                        selectedTrackIds = emptySet()
                    },
                    onShare = {
                        try {
                            val uris = ArrayList<android.net.Uri>()
                            selectedTracks.forEach { uris.add(it.uri) }
                            val intent = android.content.Intent(android.content.Intent.ACTION_SEND_MULTIPLE).apply {
                                type = "audio/*"
                                putParcelableArrayListExtra(android.content.Intent.EXTRA_STREAM, uris)
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            shareCtx.startActivity(android.content.Intent.createChooser(intent, "Compartilhar"))
                        } catch (_: Exception) {}
                        showSelectionActions = false
                    },
                    onShowInfo = if (selectedTracks.size == 1) {
                        {
                            showSelectionActions = false
                            selectionInfoTrack = selectedTracks.first()
                        }
                    } else null,
                    onEditTags = {
                        showSelectionActions = false
                        if (selectedTracks.size == 1) {
                            tagEditTrack = selectedTracks.first()
                            selectedTrackIds = emptySet()
                        } else {
                            batchTagTracks = selectedTracks
                            showBatchTagEdit = true
                        }
                    },
                    onRenameBatch = {
                        showSelectionActions = false
                        batchRenameTracks = selectedTracks
                        showBatchRename = true
                    },
                    onDelete = {
                        showSelectionActions = false
                        showDeleteConfirm = true
                    }
                )
            }

            if (showBatchTagEdit && batchTagTracks.isNotEmpty()) {
                val batchCtx = LocalContext.current
                BatchTagEditDialog(
                    count = batchTagTracks.size,
                    onDismiss = {
                        showBatchTagEdit = false
                        batchTagTracks = emptyList()
                    },
                    onConfirm = { artist, album, albumArtist, genre, year, trackTotal, discTotal ->
                        val ids = batchTagTracks.map { it.id }
                        vm.batchUpdateTags(ids, artist, album, albumArtist, genre, year, trackTotal, discTotal) { ok, fail ->
                            android.widget.Toast.makeText(
                                batchCtx,
                                if (fail == 0) "Tags atualizadas em $ok faixas"
                                else "Atualizadas: $ok · falhas: $fail",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                        showBatchTagEdit = false
                        batchTagTracks = emptyList()
                        selectedTrackIds = emptySet()
                    }
                )
            }

            if (showBatchRename && batchRenameTracks.isNotEmpty()) {
                BatchRenameDialog(
                    tracks = batchRenameTracks,
                    onDismiss = {
                        showBatchRename = false
                        batchRenameTracks = emptyList()
                    },
                    onConfirm = { pattern ->
                        // Renomeia arquivos com base no padrão de tags
                        batchRenameTracks.forEach { t ->
                            val newName = applyRenamePattern(pattern, t)
                            // Tenta renomear via ViewModel se disponível
                            try {
                                vm.renameTrackFile(t, newName)
                            } catch (_: Exception) {}
                        }
                        showBatchRename = false
                        batchRenameTracks = emptyList()
                        selectedTrackIds = emptySet()
                    }
                )
            }

            if (showOrganizeRenameDialog && organizeRenameFolder != null) {
                val dummyTracks = remember(organizeRenameFolder) {
                    listOf(
                        Track(
                            id = "org_dummy",
                            title = "Título",
                            artist = "Artista",
                            album = "Álbum",
                            genre = "",
                            duration = 0L,
                            uri = android.net.Uri.EMPTY,
                            path = "",
                            folder = ""
                        )
                    )
                }
                BatchRenameDialog(
                    tracks = dummyTracks,
                    onDismiss = {
                        showOrganizeRenameDialog = false
                        organizeRenameFolder = null
                        pendingOrganizeAction = null
                    },
                    onConfirm = { pattern ->
                        val folder = organizeRenameFolder
                        showOrganizeRenameDialog = false
                        organizeRenameFolder = null
                        pendingOrganizeAction = null
                        if (folder != null) {
                            vm.bulkRenameFolderByPattern(folder, pattern)
                        }
                    }
                )
            }


            if (showDeleteConfirm && selectedTrackIds.isNotEmpty()) {
                val pool = remember(isSearching, searchResults, visible, favoriteTracks, history, mostPlayed, tracks) {
                    if (isSearching) searchResults
                    else (visible + favoriteTracks + history + mostPlayed + tracks).distinctBy { it.id }
                }
                val tracksToDelete = remember(selectedTrackIds, pool) {
                    val byId = pool.associateBy { it.id }
                    selectedTrackIds.mapNotNull { byId[it] }
                }
                val count = selectedTrackIds.size
                AppAlertDialog(
                    onDismissRequest = { showDeleteConfirm = false },
                    title = { Text(if (count == 1) "Excluir permanentemente?" else "Excluir $count faixas?") },
                    text = {
                        Text(
                            if (count == 1) "O arquivo será apagado do armazenamento. Esta ação não pode ser desfeita."
                            else "Os arquivos serão apagados do armazenamento. Esta ação não pode ser desfeita."
                        )
                    },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                onDeleteTracks(tracksToDelete)
                                showDeleteConfirm = false
                                selectedTrackIds = emptySet()
                            }
                        ) { Text("Excluir", color = MaterialTheme.colorScheme.error) }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDeleteConfirm = false }) {
                            Text("Cancelar")
                        }
                    }
                )
            }

            // Informações técnicas da faixa selecionada (menu de multi-seleção)
            selectionInfoTrack?.let { infoTrack ->
                TechDetailsDialog(
                    track = infoTrack,
                    onDismiss = { selectionInfoTrack = null },
                    playCount = vm.playCountOf(infoTrack.id)
                )
            }

            // ---------- Adicionar a playlist ----------
            if (showAddToPlaylist && addToPlaylistTracks.isNotEmpty()) {
                AddToPlaylistDialog(
                    playlists = playlists,
                    onDismiss = {
                        showAddToPlaylist = false
                        addToPlaylistTracks = emptyList()
                    },
                    onSelect = { plId ->
                        addToPlaylistTracks.forEach { vm.addToPlaylist(plId, it.id) }
                        showAddToPlaylist = false
                        addToPlaylistTracks = emptyList()
                        selectedTrackIds = emptySet()
                    },
                    onCreateNew = {
                        createPlaylistInitialTrack = addToPlaylistTracks.firstOrNull(); createPlaylistInitialTracks = addToPlaylistTracks
                        newPlaylistName = ""
                        showAddToPlaylist = false
                        showCreatePlaylist = true
                    }
                )
            }

            // ---------- Criar playlist ----------
            if (showCreatePlaylist) {
                AppAlertDialog(
                    onDismissRequest = { showCreatePlaylist = false },
                    title = { Text("Nova playlist") },
                    text = {
                        OutlinedTextField(
                            value = newPlaylistName,
                            onValueChange = { newPlaylistName = it },
                            singleLine = true,
                            label = { Text("Nome") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val id = vm.createPlaylist(
                                newPlaylistName,
                                createPlaylistInitialTracks.map { it.id }
                            )
                            showCreatePlaylist = false
                            createPlaylistInitialTrack = null; createPlaylistInitialTracks = emptyList()
                        }) { Text("Criar") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showCreatePlaylist = false }) { Text("Cancelar") }
                    }
                )
            }
        }
    }
    } // MaterialTheme

            // Gerenciador de arquivos: tela própria (cobre nav e conteúdo)
            if (showFileManager) {
                FileManagerScreen(
                    mode = fileManagerMode,
                    initialPath = fileManagerInitialPath,
                    floatingIconsEnabled = floatingIconsEnabled,
                    appColors = appColors,
                    backdrop = backdrop,
                    onClose = {
                        showFileManager = false
                        fileManagerFolderCallback = null
                    },
                    onFolderPicked = fileManagerFolderCallback,
                    onTracksMayHaveChanged = { vm.refreshLibrary() }
                )
            }

    } // CompositionLocalProvider
}

@Composable
internal fun ArtImage(
    path: String?,
    size: Dp,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(10.dp)
) {
    val model: Any? = when {
        path.isNullOrBlank() -> null
        path.startsWith("http://") || path.startsWith("https://") -> path
        else -> File(path).takeIf { it.exists() }
    }
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(Color.White.copy(alpha = 0.08f)),
        contentAlignment = Alignment.Center
    ) {
        if (model != null) {
            AsyncImage(
                model = model,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                Icons.Rounded.MusicNote,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.35f),
                modifier = Modifier.size(size * 0.45f)
            )
        }
    }
}

@Composable
private fun Header(
    title: String,
    showBack: Boolean,
    onBack: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenHelp: () -> Unit,
    onOpenSettings: () -> Unit,
    onPlayAllShuffled: (() -> Unit)? = null,
    onOpenFileManager: (() -> Unit)? = null
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (showBack) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Voltar")
            }
        }
        Text(
            text = title,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(start = if (showBack) 0.dp else 12.dp)
        )
        Box(
            Modifier
                .height(36.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color.White.copy(alpha = 0.12f))
                .clickable(onClick = onOpenSearch)
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Rounded.Search,
                    contentDescription = "Buscar",
                    modifier = Modifier.size(18.dp),
                    tint = Color.White.copy(0.85f)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    "Buscar",
                    fontSize = 13.sp,
                    color = Color.White.copy(0.7f)
                )
            }
        }
        if (onPlayAllShuffled != null) {
            IconButton(onClick = onPlayAllShuffled) {
                Icon(Icons.Rounded.Shuffle, contentDescription = "Tocar todas aleatório")
            }
        }
        if (onOpenFileManager != null) {
            IconButton(onClick = onOpenFileManager) {
                Image(
                    painter = painterResource(R.drawable.ic_header_files),
                    contentDescription = "Gerenciador de arquivos",
                    modifier = Modifier.size(28.dp)
                )
            }
        }
        IconButton(onClick = onOpenHelp) {
            Image(
                painter = painterResource(R.drawable.ic_help_button),
                contentDescription = "Ajuda",
                modifier = Modifier.size(28.dp)
            )
        }
        IconButton(onClick = onOpenSettings) {
            Image(
                painter = painterResource(R.drawable.ic_header_settings),
                contentDescription = "Configurações",
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SearchResultsPanel(
    tracks: List<Track>,
    artists: List<Artist>,
    albums: List<Album>,
    genres: List<Genre>,
    nowPlayingId: String?,
    bottomPadding: Dp,
    selectedIds: Set<String>,
    selectionMode: Boolean,
    onTrackClick: (Int, Track) -> Unit,
    onTrackLongClick: (Track) -> Unit,
    onOpenArtist: (String) -> Unit,
    onOpenAlbum: (String) -> Unit,
    onOpenGenre: (String) -> Unit
) {
    val searchCtx = LocalContext.current
    val hasGroups = artists.isNotEmpty() || albums.isNotEmpty() || genres.isNotEmpty()
    if (!hasGroups) {
        TrackList(
            tracks = tracks,
            nowPlayingId = nowPlayingId,
            bottomPadding = bottomPadding,
            showTrackNumbers = false,
            selectedIds = selectedIds,
            selectionMode = selectionMode,
            onClick = onTrackClick,
            onLongClick = onTrackLongClick,
            showAlphabetScroller = false
        )
        return
    }
    LazyColumn(contentPadding = PaddingValues(top = 8.dp, bottom = bottomPadding)) {
        if (artists.isNotEmpty()) {
            item {
                Text(
                    "Artistas",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(0.55f),
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }
            items(artists.take(20)) { a ->
                val metaImg = ArtistMetaStore.cachedPhotoPath(a.name)
                val art = metaImg ?: a.artPath
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpenArtist(a.name) }
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ArtImage(path = art, size = 48.dp, shape = CircleShape)
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text(a.name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            faixas(a.trackCount),
                            fontSize = 13.sp,
                            color = Color.White.copy(0.6f)
                        )
                    }
                }
            }
        }
        if (albums.isNotEmpty()) {
            item {
                Text(
                    "Álbuns",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(0.55f),
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }
            items(albums.take(20)) { al ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpenAlbum("album-key::${al.key}") }
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ArtImage(path = al.artPath, size = 48.dp, shape = RoundedCornerShape(10.dp))
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text(al.name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${al.artist} · ${faixas(al.trackCount)}",
                            fontSize = 13.sp,
                            color = Color.White.copy(0.6f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
        if (genres.isNotEmpty()) {
            item {
                Text(
                    "Gêneros",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(0.55f),
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }
            items(genres.take(20)) { g ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpenGenre(g.name) }
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ArtImage(path = g.artPath, size = 48.dp, shape = RoundedCornerShape(10.dp))
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text(g.name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            faixas(g.trackCount),
                            fontSize = 13.sp,
                            color = Color.White.copy(0.6f)
                        )
                    }
                }
            }
        }
        if (tracks.isNotEmpty()) {
            item {
                Text(
                    "Faixas",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(0.55f),
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }
            itemsIndexed(tracks, key = { _, t -> t.id }) { index, track ->
                val active = track.id == nowPlayingId
                val selected = track.id in selectedIds
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(if (selected) Color.White.copy(alpha = 0.12f) else Color.Transparent)
                        .combinedClickable(
                            onClick = { onTrackClick(index, track) },
                            onLongClick = { onTrackLongClick(track) }
                        )
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (selectionMode) {
                        Box(
                            Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (selected) {
                                Text("✓", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                    }
                    ArtImage(path = track.artPath, size = 48.dp)
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text(
                            track.title,
                            fontSize = 16.sp,
                            color = if (active) MaterialTheme.colorScheme.primary else Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "${track.artist} · ${track.album}",
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.6f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        formatDuration(track.duration),
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.6f),
                        modifier = Modifier.padding(start = 12.dp)
                    )
                }
            }
        }
    }
}

@Composable
internal fun SearchHeader(
    query: String,
    onQueryChange: (String) -> Unit,
    onClose: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClose) {
            Icon(Icons.Rounded.ArrowBack, contentDescription = "Fechar busca")
        }
        BasicTextField(
            value = query,
            onValueChange = onQueryChange,
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp),
            decorationBox = { inner ->
                Box {
                    if (query.isEmpty()) {
                        Text("Buscar músicas…", color = Color.White.copy(0.45f), fontSize = 18.sp)
                    }
                    inner()
                }
            }
        )
        if (query.isNotEmpty()) {
            IconButton(onClick = { onQueryChange("") }) {
                Icon(Icons.Rounded.Close, contentDescription = "Limpar")
            }
        }
    }
}

@Composable
private fun GroupList(items: List<GroupItem>, bottomPadding: Dp, onClick: (String) -> Unit) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val letterIndex = remember(items) {
        buildLetterIndex(items) { it.title }
    }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(top = 8.dp, bottom = bottomPadding, end = 20.dp)
        ) {
            items(items) { item ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onClick(item.key) }
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ArtImage(
                        path = item.artPath,
                        size = 56.dp,
                        shape = if (item.round) CircleShape else RoundedCornerShape(10.dp)
                    )
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text(item.title, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            item.subtitle,
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.6f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
        AlphabetFastScroller(
            letterIndex = letterIndex,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .padding(vertical = 12.dp, horizontal = 2.dp),
            onLetterSelected = { letter ->
                letterIndex[letter]?.let { idx ->
                    scope.launch { listState.scrollToItem(idx.coerceIn(0, items.lastIndex.coerceAtLeast(0))) }
                }
            }
        )
    }
}

/** Índice da primeira ocorrência de cada letra (A–Z / #). */
private fun <T> buildLetterIndex(items: List<T>, label: (T) -> String): Map<Char, Int> {
    val map = linkedMapOf<Char, Int>()
    items.forEachIndexed { index, item ->
        val c = label(item).firstOrNull()?.uppercaseChar()
        val key = if (c != null && c in 'A'..'Z') c else '#'
        if (key !in map) map[key] = index
    }
    return map
}

private val AlphabetLetters = listOf('#') + ('A'..'Z').toList()

@Composable
private fun AlphabetFastScroller(
    letterIndex: Map<Char, Int>,
    modifier: Modifier = Modifier,
    onLetterSelected: (Char) -> Unit
) {
    if (letterIndex.isEmpty()) return
    var activeLetter by remember { mutableStateOf<Char?>(null) }
    var fingerFraction by remember { mutableStateOf(0f) }
    BoxWithConstraints(modifier = modifier) {
        val trackHeight = maxHeight
        Column(
            modifier = Modifier
                .width(22.dp)
                .fillMaxHeight()
                .align(Alignment.CenterEnd)
                .pointerInput(letterIndex) {
                    detectVerticalDragGestures(
                        onDragStart = { offset ->
                            val h = size.height.toFloat().coerceAtLeast(1f)
                            fingerFraction = (offset.y / h).coerceIn(0f, 1f)
                            val letter = letterAtY(offset.y, h)
                            activeLetter = letter
                            onLetterSelected(letter)
                        },
                        onDragEnd = { activeLetter = null },
                        onDragCancel = { activeLetter = null },
                        onVerticalDrag = { change, _ ->
                            change.consume()
                            val h = size.height.toFloat().coerceAtLeast(1f)
                            fingerFraction = (change.position.y / h).coerceIn(0f, 1f)
                            val letter = letterAtY(change.position.y, h)
                            if (letter != activeLetter) {
                                activeLetter = letter
                                onLetterSelected(letter)
                            }
                        }
                    )
                },
            verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AlphabetLetters.forEach { letter ->
                val present = letter in letterIndex
                val active = activeLetter == letter
                Text(
                    text = letter.toString(),
                    fontSize = if (active) 12.sp else 10.sp,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                    color = when {
                        active -> Color.White
                        present -> Color.White.copy(0.75f)
                        else -> Color.White.copy(0.28f)
                    },
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = present) {
                            activeLetter = letter
                            onLetterSelected(letter)
                        }
                )
            }
        }
        activeLetter?.let { letter ->
            val bubbleY = (trackHeight * fingerFraction) - 26.dp
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-40).dp, y = bubbleY)
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.95f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    letter.toString(),
                    color = Color.Black,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun letterAtY(y: Float, height: Float): Char {
    if (height <= 0f) return '#'
    val fraction = (y / height).coerceIn(0f, 0.999f)
    val idx = (fraction * AlphabetLetters.size).toInt().coerceIn(0, AlphabetLetters.lastIndex)
    return AlphabetLetters[idx]
}

@Composable
internal fun PlaylistList(
    playlists: List<Playlist>,
    trackCount: (String) -> Int,
    bottomPadding: Dp,
    onOpen: (String) -> Unit,
    onCreate: () -> Unit,
    onImport: () -> Unit,
    onExport: (Playlist) -> Unit,
    onDelete: (Playlist) -> Unit = {},
    onReorder: (List<String>) -> Unit = {}
) {
    val visible = playlists.filter { !it.isFavorites }
    var organizing by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<Playlist?>(null) }
    val listState = rememberLazyListState()
    val dragScope = rememberCoroutineScope()
    var draggingId by remember { mutableStateOf<String?>(null) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }
    var dropTargetId by remember { mutableStateOf<String?>(null) }
    var dropAfter by remember { mutableStateOf(false) }
    var autoScrollJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    val accent = MaterialTheme.colorScheme.primary

    fun updateDropTarget() {
        val id = draggingId ?: return
        val ids = visible.map { it.id }.toSet()
        val infos = listState.layoutInfo.visibleItemsInfo.filter { (it.key as? String) in ids }
        val me = infos.firstOrNull { it.key == id } ?: return
        val center = me.offset + me.size / 2f + dragOffsetY
        val target = infos.firstOrNull { center >= it.offset && center < it.offset + it.size }
            ?: if (center < (infos.firstOrNull()?.offset ?: 0)) infos.firstOrNull() else infos.lastOrNull()
        if (target == null) return
        dropTargetId = target.key as? String
        dropAfter = target.index > me.index
    }

    fun stopDrag() {
        autoScrollJob?.cancel(); autoScrollJob = null
        draggingId = null; dropTargetId = null; dragOffsetY = 0f
    }

    fun finishDrag() {
        val id = draggingId
        val targetId = dropTargetId
        if (id != null && targetId != null && targetId != id) {
            val ids = visible.map { it.id }.toMutableList()
            val from = ids.indexOf(id)
            val targetIdx = ids.indexOf(targetId)
            if (from >= 0 && targetIdx >= 0) {
                val to = if (dropAfter) {
                    if (targetIdx >= from) targetIdx else targetIdx + 1
                } else {
                    if (targetIdx > from) targetIdx - 1 else targetIdx
                }.coerceIn(0, ids.lastIndex)
                if (to != from) {
                    ids.add(to, ids.removeAt(from))
                    onReorder(ids)
                }
            }
        }
        stopDrag()
    }

    fun startAutoScroll() {
        autoScrollJob?.cancel()
        autoScrollJob = dragScope.launch {
            while (draggingId != null) {
                val info = listState.layoutInfo
                val me = info.visibleItemsInfo.firstOrNull { it.key == draggingId }
                if (me != null) {
                    val top = me.offset + dragOffsetY
                    val bottom = top + me.size
                    val edge = me.size * 0.9f
                    val viewportEnd = info.viewportEndOffset - info.afterContentPadding
                    val delta = when {
                        top < info.viewportStartOffset + edge -> -18f
                        bottom > viewportEnd - edge -> 18f
                        else -> 0f
                    }
                    if (delta != 0f) {
                        dragOffsetY += listState.scrollBy(delta)
                        updateDropTarget()
                    }
                }
                kotlinx.coroutines.delay(16)
            }
        }
    }

    pendingDelete?.let { pl ->
        AppAlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Excluir playlist") },
            text = { Text("“${pl.name}” será excluída. As músicas continuam no aparelho.") },
            confirmButton = {
                TextButton(onClick = { pendingDelete = null; onDelete(pl) }) {
                    Text("Excluir", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancelar") } }
        )
    }

    LazyColumn(state = listState, contentPadding = PaddingValues(top = 8.dp, bottom = bottomPadding)) {
        item(key = "header") {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!organizing) {
                    TextButton(onClick = onCreate) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Nova")
                    }
                    TextButton(onClick = onImport) {
                        Icon(Icons.Rounded.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Importar .m3u")
                    }
                }
                Spacer(Modifier.weight(1f))
                if (visible.isNotEmpty()) {
                    TextButton(onClick = { stopDrag(); organizing = !organizing }) {
                        Icon(
                            if (organizing) Icons.Rounded.Done else Icons.Rounded.SwapVert,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(if (organizing) "Concluir" else "Organizar")
                    }
                }
            }
        }
        items(visible, key = { it.id }) { pl ->
            val isDragging = draggingId == pl.id
            val lineAbove = dropTargetId == pl.id && !dropAfter && !isDragging
            val lineBelow = dropTargetId == pl.id && dropAfter && !isDragging
            Box {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .graphicsLayer {
                            if (isDragging) {
                                translationY = dragOffsetY
                                alpha = 0.92f
                                scaleX = 1.03f
                                scaleY = 1.03f
                                shadowElevation = 16f
                            }
                        }
                        .zIndex(if (isDragging) 1f else 0f)
                        .then(if (isDragging) Modifier.background(Color(0xFF1E1E26), RoundedCornerShape(12.dp)) else Modifier)
                        .clickable(enabled = !organizing) { onOpen(pl.id) }
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("♪", fontSize = 22.sp, color = Color.White.copy(0.7f))
                    }
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text(pl.name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(faixas(trackCount(pl.id)), fontSize = 13.sp, color = Color.White.copy(alpha = 0.6f))
                    }
                    if (organizing) {
                        IconButton(onClick = { pendingDelete = pl }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Excluir playlist", tint = Color(0xFFE53935))
                        }
                        Icon(
                            Icons.Rounded.DragHandle,
                            contentDescription = "Arrastar para reordenar",
                            tint = Color.White.copy(0.55f),
                            modifier = Modifier
                                .padding(horizontal = 8.dp)
                                .size(28.dp)
                                .pointerInput(pl.id) {
                                    detectDragGestures(
                                        onDragStart = {
                                            draggingId = pl.id
                                            dragOffsetY = 0f
                                            dropTargetId = null
                                            updateDropTarget()
                                            startAutoScroll()
                                        },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            dragOffsetY += amount.y
                                            updateDropTarget()
                                        },
                                        onDragEnd = { finishDrag() },
                                        onDragCancel = { stopDrag() }
                                    )
                                }
                        )
                    } else {
                        IconButton(onClick = { onExport(pl) }) {
                            Icon(Icons.Rounded.FileUpload, contentDescription = "Exportar .m3u", tint = Color.White.copy(0.7f))
                        }
                    }
                }
                if (lineAbove) {
                    Box(
                        Modifier.align(Alignment.TopCenter).padding(horizontal = 16.dp).fillMaxWidth()
                            .height(3.dp).clip(RoundedCornerShape(2.dp)).background(accent)
                    )
                }
                if (lineBelow) {
                    Box(
                        Modifier.align(Alignment.BottomCenter).padding(horizontal = 16.dp).fillMaxWidth()
                            .height(3.dp).clip(RoundedCornerShape(2.dp)).background(accent)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TrackList(
    tracks: List<Track>,
    nowPlayingId: String?,
    bottomPadding: Dp,
    showTrackNumbers: Boolean = false,
    selectedIds: Set<String> = emptySet(),
    selectionMode: Boolean = false,
    onClick: (Int, Track) -> Unit,
    onLongClick: (Track) -> Unit,
    showAlphabetScroller: Boolean = true
) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val letterIndex = remember(tracks) {
        if (showAlphabetScroller) buildLetterIndex(tracks) { it.title } else emptyMap()
    }
    Box(Modifier.fillMaxSize()) {
    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(top = 8.dp, bottom = bottomPadding, end = if (showAlphabetScroller) 20.dp else 0.dp)
    ) {
        itemsIndexed(tracks, key = { _, t -> t.id }) { index, track ->
            val active = track.id == nowPlayingId
            val selected = track.id in selectedIds
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(if (selected) Color.White.copy(alpha = 0.12f) else Color.Transparent)
                    .combinedClickable(
                        onClick = { onClick(index, track) },
                        onLongClick = { onLongClick(track) }
                    )
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (selectionMode) {
                    Box(
                        Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (selected) {
                            Text("✓", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                } else if (showTrackNumbers) {
                    Text(
                        track.trackNumber?.toString() ?: "–",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White.copy(0.7f),
                        modifier = Modifier.width(28.dp)
                    )
                }
                ArtImage(path = track.artPath, size = 48.dp)
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(
                        track.title,
                        fontSize = 16.sp,
                        color = if (active) MaterialTheme.colorScheme.primary else Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "${track.artist} · ${track.album}",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.6f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    formatDuration(track.duration),
                    fontSize = 13.sp,
                    color = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.padding(start = 12.dp)
                )
            }
        }
    }
    if (showAlphabetScroller && letterIndex.isNotEmpty()) {
        AlphabetFastScroller(
            letterIndex = letterIndex,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .padding(vertical = 12.dp, horizontal = 2.dp),
            onLetterSelected = { letter ->
                letterIndex[letter]?.let { idx ->
                    scope.launch { listState.scrollToItem(idx.coerceIn(0, tracks.lastIndex.coerceAtLeast(0))) }
                }
            }
        )
    }
    } // Box
}

@Composable
private fun MiniPlayer(
    track: Track,
    isPlaying: Boolean,
    backdrop: GraphicsLayer,
    onClick: () -> Unit,
    onPrevious: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit
) {
    GlassSurface(
        backdrop = backdrop,
        shape = RoundedCornerShape(28.dp),
        style = GlassStyle.Bar,
        blurRadius = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(start = 10.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ArtImage(path = track.artPath, size = 44.dp, shape = RoundedCornerShape(12.dp))
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(track.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, fontSize = 12.sp, color = Color.White.copy(alpha = 0.75f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onPrevious) { Icon(Icons.Rounded.SkipPrevious, contentDescription = "Anterior") }
            IconButton(onClick = onToggle) {
                Icon(
                    if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (isPlaying) "Pausar" else "Tocar"
                )
            }
            IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, contentDescription = "Próxima") }
        }
    }
}

/** Menu de ações para multi-seleção. */
@Composable
private fun SelectionActionsMenu(
    count: Int,
    backdrop: GraphicsLayer,
    onDismiss: () -> Unit,
    onClearSelection: () -> Unit,
    onSelectAll: () -> Unit = {},
    onPlayNext: () -> Unit,
    onPlayLast: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onFavorite: () -> Unit,
    onShare: () -> Unit = {},
    onShowInfo: (() -> Unit)? = null,
    onEditTags: (() -> Unit)? = null,
    onRenameBatch: (() -> Unit)? = null,
    onDelete: () -> Unit
) {
    val menuStyle = LocalMenuVisualStyle.current
    val pal = menuPalette(LocalAppColors.current, menuStyle)
    val glassMenu = menuStyle == MenuVisualStyle.GLASS
    // onEditTags: 1 faixa = editor completo; várias = edição em lote (Artista/Álbum/Artista do Álbum)
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.45f))
                .clickable(onClick = onDismiss),
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 72.dp) // um pouco mais alto que o fundo da tela
                    .navigationBarsPadding()
                    .clickable(enabled = false) {}
            ) {
                val menuContent: @Composable () -> Unit = {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .background(
                                when {
                                    glassMenu -> Color.Transparent
                                    menuStyle == MenuVisualStyle.COLORFUL -> pal.container.copy(alpha = 0.72f)
                                    else -> pal.container
                                }
                            )
                            .padding(vertical = 8.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            if (count == 1) "1 faixa selecionada" else "$count faixas selecionadas",
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = pal.content,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        MenuRow("Marcar todas", onSelectAll)
                        MenuRow("Reproduzir a seguir", onPlayNext)
                        MenuRow("Reproduzir no final", onPlayLast)
                        MenuRow("Adicionar a uma Playlist", onAddToPlaylist)
                        MenuRow("Favoritar", onFavorite)
                        MenuRow("Compartilhar", onShare)
                        if (count == 1 && onShowInfo != null) {
                            MenuRow("Informações", onShowInfo)
                        }
                        if (onEditTags != null) {
                            MenuRow(
                                if (count == 1) "Editar tags" else "Editar tags em lote",
                                onEditTags
                            )
                        }
                        if (onRenameBatch != null) {
                            MenuRow("Renomear por tags", onRenameBatch)
                        }
                        MenuRow("Excluir", onDelete, textColor = pal.danger)
                        MenuRow("Desmarcar Todas", onClearSelection)
                    }
                }
                if (glassMenu) {
                    GlassSurface(
                        backdrop = backdrop,
                        sourceOrigin = LocalGlassBackdropOrigin.current,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.fillMaxWidth().heightIn(max = 460.dp),
                        style = GlassStyle.Panel.copy(
                            refraction = 6.dp,
                            edgeWidth = 14.dp,
                            magnification = 0.015f,
                            dispersion = 0.18f
                        )
                    ) {
                        if (GlassConfig.quality == GlassQuality.LIGHT) menuContent()
                        else GlassLensContent { menuContent() }
                    }
                } else {
                    Surface(
                        color = pal.container,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.fillMaxWidth().heightIn(max = 460.dp)
                    ) { menuContent() }
                }
            }
        }
    }
}

@Composable
private fun MenuRow(label: String, onClick: () -> Unit, textColor: Color = Color.Unspecified) {
    val resolved = if (textColor == Color.Unspecified) {
        menuPalette(LocalAppColors.current, LocalMenuVisualStyle.current).content
    } else textColor
    Text(
        text = label,
        modifier = Modifier
            .fillMaxWidth()
            .lensRow(onClick)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        fontSize = 16.sp,
        color = resolved
    )
}

@Composable
private fun AddToPlaylistDialog(
    playlists: List<Playlist>,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
    onCreateNew: () -> Unit
) {
    AppAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar a playlist") },
        text = {
            Column {
                playlists.forEach { pl ->
                    Text(
                        pl.name,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(pl.id) }
                            .padding(vertical = 12.dp),
                        fontSize = 16.sp
                    )
                }
                Text(
                    "+ Criar nova playlist",
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onCreateNew)
                        .padding(vertical = 12.dp),
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}


@Composable
private fun SortBar(
    isGroup: Boolean,
    groupSort: MusicViewModel.GroupSort,
    groupOrder: MusicViewModel.SortOrder,
    trackSort: MusicViewModel.TrackSort,
    trackOrder: MusicViewModel.SortOrder,
    onGroupSort: (MusicViewModel.GroupSort, MusicViewModel.SortOrder) -> Unit,
    onTrackSort: (MusicViewModel.TrackSort, MusicViewModel.SortOrder) -> Unit,
    compact: Boolean = false
) {
    var expanded by remember { mutableStateOf(false) }
    val label = if (isGroup) {
        val s = when (groupSort) {
            MusicViewModel.GroupSort.NAME -> "Nome"
            MusicViewModel.GroupSort.TRACK_COUNT -> "Qtd. músicas"
            MusicViewModel.GroupSort.TOTAL_DURATION -> "Duração total"
        }
        val o = if (groupOrder == MusicViewModel.SortOrder.ASC) "↑" else "↓"
        "$s $o"
    } else {
        val s = when (trackSort) {
            MusicViewModel.TrackSort.NAME -> "Nome"
            MusicViewModel.TrackSort.FILE_SIZE -> "Tamanho"
            MusicViewModel.TrackSort.DURATION -> "Duração"
            MusicViewModel.TrackSort.LAST_MODIFIED -> "Atualização"
        }
        val o = if (trackOrder == MusicViewModel.SortOrder.ASC) "↑" else "↓"
        "$s $o"
    }
    Box(
        Modifier
            .then(if (compact) Modifier else Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp))
    ) {
        Row(
            Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(0.10f))
                .clickable { expanded = true }
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Ordenar: $label", fontSize = 13.sp, color = Color.White.copy(0.85f))
        }
        AppDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            if (isGroup) {
                listOf(
                    MusicViewModel.GroupSort.NAME to "Nome",
                    MusicViewModel.GroupSort.TRACK_COUNT to "Quantidade de músicas",
                    MusicViewModel.GroupSort.TOTAL_DURATION to "Duração total"
                ).forEach { (sort, name) ->
                    LensMenuItem(
                        text = { Text("$name ↑") },
                        onClick = {
                            onGroupSort(sort, MusicViewModel.SortOrder.ASC)
                            expanded = false
                        }
                    )
                    LensMenuItem(
                        text = { Text("$name ↓") },
                        onClick = {
                            onGroupSort(sort, MusicViewModel.SortOrder.DESC)
                            expanded = false
                        }
                    )
                }
            } else {
                listOf(
                    MusicViewModel.TrackSort.NAME to "Nome",
                    MusicViewModel.TrackSort.FILE_SIZE to "Tamanho do arquivo",
                    MusicViewModel.TrackSort.DURATION to "Duração da faixa",
                    MusicViewModel.TrackSort.LAST_MODIFIED to "Última atualização"
                ).forEach { (sort, name) ->
                    LensMenuItem(
                        text = { Text("$name ↑") },
                        onClick = {
                            onTrackSort(sort, MusicViewModel.SortOrder.ASC)
                            expanded = false
                        }
                    )
                    LensMenuItem(
                        text = { Text("$name ↓") },
                        onClick = {
                            onTrackSort(sort, MusicViewModel.SortOrder.DESC)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}


private data class ArtistAlbumItem(
    val name: String,
    val trackCount: Int,
    val artPath: String?,
    val totalDurationMs: Long,
    val year: Int? = null
)

@Composable
private fun AlbumWikiInfoSection(
    albumName: String,
    artistName: String?
) {
    val context = LocalContext.current
    val prefs = remember {
        context.getSharedPreferences("wikidata_overrides", Context.MODE_PRIVATE)
    }
    val overrideKey = "album_info_${albumName}_${artistName.orEmpty()}"
    var manualInfo by remember {
        mutableStateOf(prefs.getString(overrideKey, null))
    }
    var wikiInfo by remember { mutableStateOf<com.tolete.player.data.WikidataClient.EntityInfo?>(null) }
    var loadingWiki by remember { mutableStateOf(true) }
    var editingInfo by remember { mutableStateOf(false) }
    var editText by remember { mutableStateOf("") }
    var textExpanded by remember { mutableStateOf(false) }


    var lastFmSummary by remember { mutableStateOf<String?>(null) }
    var savedAlbum by remember(albumName, artistName) { mutableStateOf<ArtistMetaStore.Meta?>(null) }
    LaunchedEffect(albumName, artistName) {
        loadingWiki = true
        val albumMetaKey = ArtistMetaStore.albumKey(albumName, artistName)
        savedAlbum = withContext(Dispatchers.IO) { ArtistMetaStore.load(context, albumMetaKey) }
        wikiInfo = withContext(Dispatchers.IO) {
            com.tolete.player.data.WikidataClient.searchAlbum(albumName, artistName)
        }
        val txt = wikiInfo?.extract ?: wikiInfo?.description
        if (txt.isNullOrBlank()) {
            val lfm = withContext(Dispatchers.IO) { LastFmClient.getAlbumInfo(albumName, artistName) }
            lastFmSummary = lfm?.summary
            if (!lfm?.summary.isNullOrBlank() && manualInfo.isNullOrBlank()) {
                withContext(Dispatchers.IO) {
                    ArtistMetaStore.saveText(context, albumMetaKey, lfm?.summary, "lastfm")
                }
            }
        } else if (manualInfo.isNullOrBlank()) {
            withContext(Dispatchers.IO) {
                ArtistMetaStore.saveText(context, albumMetaKey, txt, "wikidata")
            }
        }
        loadingWiki = false
    }

    val displayInfo = manualInfo ?: savedAlbum?.text ?: wikiInfo?.extract ?: wikiInfo?.description ?: lastFmSummary

    Column(Modifier.padding(top = 6.dp)) {
        if (editingInfo) {
            OutlinedTextField(
                value = editText,
                onValueChange = { editText = it },
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 13.sp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.White.copy(0.5f),
                    unfocusedBorderColor = Color.White.copy(0.25f),
                    cursorColor = Color.White
                ),
                minLines = 2,
                maxLines = 6
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = { editingInfo = false }) {
                    Text("Cancelar", color = Color.White.copy(0.7f))
                }
                TextButton(onClick = {
                    manualInfo = editText.trim().ifBlank { null }
                    prefs.edit().putString(overrideKey, manualInfo).apply()
                    editingInfo = false
                }) {
                    Text("Salvar", color = Color(0xFF82B1FF))
                }
            }
        } else {
            when {
                !displayInfo.isNullOrBlank() -> Text(
                    displayInfo,
                    fontSize = 13.sp,
                    color = Color.White.copy(0.72f),
                    maxLines = if (textExpanded) Int.MAX_VALUE else 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.clickable { textExpanded = !textExpanded }
                )
                loadingWiki -> Text(
                    "Buscando informações do álbum…",
                    fontSize = 12.sp,
                    color = Color.White.copy(0.4f)
                )
            }
            TextButton(
                onClick = {
                    editText = displayInfo ?: ""
                    editingInfo = true
                },
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
            ) {
                Text(
                    if (displayInfo.isNullOrBlank()) "Adicionar info do álbum" else "Editar info",
                    fontSize = 12.sp,
                    color = Color(0xFF82B1FF)
                )
            }
        }
    }
}

private fun formatTotalDuration(ms: Long): String {
    val totalMin = (ms / 60_000L).toInt()
    return if (totalMin < 60) "$totalMin min"
    else {
        val h = totalMin / 60
        val m = totalMin % 60
        if (m == 0) "${h} h" else "${h} h ${m} min"
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
private fun ArtistDetailScreen(
    artistName: String,
    trackCount: Int,
    totalDurationMs: Long,
    albums: List<ArtistAlbumItem>,
    tracks: List<Track> = emptyList(),
    bottomPadding: Dp,
    nowPlayingId: String? = null,
    accent: Color = Color.White,
    selectedIds: Set<String> = emptySet(),
    selectionMode: Boolean = false,
    onOpenAlbum: (String) -> Unit,
    onPlayAll: () -> Unit = {},
    onShuffle: () -> Unit = {},
    onTrackClick: (Int, Track) -> Unit = { _, _ -> },
    onTrackLongClick: (Track) -> Unit = {},
    onRefreshTags: (() -> Unit)? = null,
    onPlayTracks: ((List<Track>, Int) -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val metaKey = remember(artistName) { ArtistMetaStore.artistKey(artistName) }
    // Carregado em IO dentro do LaunchedEffect abaixo (nada de disco na composição)
    var savedMeta by remember(artistName) { mutableStateOf<ArtistMetaStore.Meta?>(null) }

    var remoteImage by remember { mutableStateOf<String?>(null) }
    var remoteText by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var editingInfo by remember { mutableStateOf(false) }
    var editText by remember { mutableStateOf("") }
    var textExpanded by remember { mutableStateOf(false) }
    // Busca manual com preview + fonte antes de aplicar
    var showManualSearch by remember { mutableStateOf(false) }
    var manualQuery by remember(artistName) { mutableStateOf(artistName) }
    var manualCandidates by remember {
        mutableStateOf<List<com.tolete.player.data.ArtistImageResolver.Candidate>>(emptyList())
    }
    var manualSearching by remember { mutableStateOf(false) }
    var manualError by remember { mutableStateOf<String?>(null) }
    fun runManualSearch(q: String) {
        manualSearching = true
        manualError = null
        manualCandidates = emptyList()
        scope.launch {
            try {
                manualCandidates = withContext(Dispatchers.IO) {
                    com.tolete.player.data.ArtistImageResolver.searchCandidates(q.trim())
                }
                if (manualCandidates.isEmpty()) manualError = "Nenhum resultado encontrado"
            } catch (e: Exception) {
                manualError = e.message ?: "Falha na busca"
            } finally {
                manualSearching = false
            }
        }
    }

    // Ordenação dos álbuns do artista: nome ou ano, crescente/decrescente
    var albumSortBy by remember { mutableStateOf("name") } // "name" | "year"
    var albumSortAsc by remember { mutableStateOf(true) }
    // Ordenação das músicas do artista: album | year | title | duration
    var trackSortMode by remember { mutableStateOf("album") }
    var trackSortAsc by remember { mutableStateOf(true) }
    val sortedArtistTracks = remember(tracks, trackSortMode, trackSortAsc) {
        val base = when (trackSortMode) {
            "year" -> tracks.sortedWith(compareBy<Track> { it.year ?: Int.MAX_VALUE }.thenBy { it.album.lowercase() }.thenBy { it.trackNumber ?: Int.MAX_VALUE })
            "title" -> tracks.sortedBy { it.title.lowercase() }
            "duration" -> tracks.sortedBy { it.duration }
            else -> tracks.sortedWith(compareBy<Track> { it.album.lowercase() }.thenBy { it.trackNumber ?: Int.MAX_VALUE }.thenBy { it.title.lowercase() })
        }
        if (trackSortAsc) base else base.reversed()
    }
    var mbYears by remember(artistName) { mutableStateOf<Map<String, Int>>(emptyMap()) }
    LaunchedEffect(artistName, albums) {
        // Limita a 4 álbuns e busca em paralelo para não travar a UI do artista
        val missing = albums.filter { it.year == null }.map { it.name }.distinct().take(4)
        if (missing.isEmpty()) return@LaunchedEffect
        val map = withContext(Dispatchers.IO) {
            kotlinx.coroutines.coroutineScope {
                missing.map { name ->
                    async {
                        try {
                            name to com.tolete.player.data.MusicBrainzClient.releaseYear(name, artistName)
                        } catch (_: Exception) {
                            name to null
                        }
                    }
                }.awaitAll().mapNotNull { (n, y) -> y?.let { n to it } }.toMap()
            }
        }
        if (map.isNotEmpty()) mbYears = map
    }
    val albumsWithYear = remember(albums, mbYears) {
        albums.map { a ->
            if (a.year != null) a else a.copy(year = mbYears[a.name])
        }
    }
    val sortedAlbums = remember(albumsWithYear, albumSortBy, albumSortAsc) {
        val albums = albumsWithYear
        val base = when (albumSortBy) {
            "year" -> albums.sortedWith(
                compareBy<ArtistAlbumItem> { it.year ?: Int.MAX_VALUE }.thenBy { it.name.lowercase() }
            )
            else -> albums.sortedBy { it.name.lowercase() }
        }
        if (albumSortAsc) base else base.reversed()
    }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val newMeta = withContext(Dispatchers.IO) {
                    val path = ArtistMetaStore.saveLocalPhoto(context, metaKey, uri)
                    if (path != null) ArtistMetaStore.load(context, metaKey) else null
                }
                if (newMeta != null) {
                    savedMeta = newMeta
                    Toast.makeText(context, "Foto do artista salva", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Falha ao salvar foto", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    LaunchedEffect(artistName) {
        loading = true
        // 1) Cache local (disco sempre fora da thread principal)
        val meta = withContext(Dispatchers.IO) {
            var m = ArtistMetaStore.load(context, metaKey)
            if (m?.text == null) {
                val old = context.getSharedPreferences("wikidata_overrides", Context.MODE_PRIVATE)
                    .getString("artist_info_$artistName", null)
                if (!old.isNullOrBlank()) {
                    ArtistMetaStore.saveText(context, metaKey, old, "manual")
                    m = ArtistMetaStore.load(context, metaKey)
                }
            }
            m
        }
        savedMeta = meta

        // 2) Só vai à rede se faltar foto ou texto; download/gravação também em IO
        val needImage = meta?.displayImage == null
        val needText = meta?.text.isNullOrBlank()
        if (needImage || needText) {
            val resolved = withContext(Dispatchers.IO) {
                val r = com.tolete.player.data.ArtistImageResolver.resolve(artistName)
                if (needImage && !r.imageUrl.isNullOrBlank()) {
                    ArtistMetaStore.saveRemoteImage(context, metaKey, r.imageUrl, r.source)
                }
                if (needText && !r.bio.isNullOrBlank()) {
                    ArtistMetaStore.saveText(context, metaKey, r.bio, r.source)
                }
                r
            }
            if (needImage && !resolved.imageUrl.isNullOrBlank()) remoteImage = resolved.imageUrl
            if (needText && !resolved.bio.isNullOrBlank()) remoteText = resolved.bio
            savedMeta = withContext(Dispatchers.IO) { ArtistMetaStore.load(context, metaKey) }
        }
        loading = false
    }

    val displayInfo = savedMeta?.text ?: remoteText
    val photoModel: Any? = savedMeta?.localImagePath?.let { File(it) }
        ?: savedMeta?.imageUrl
        ?: remoteImage

    var refreshing by remember { mutableStateOf(false) }
    val pullState = rememberPullToRefreshState()

    PullToRefreshBox(
        isRefreshing = refreshing,
        onRefresh = {
            if (onRefreshTags == null || refreshing) return@PullToRefreshBox
            refreshing = true
            savedMeta = null
            remoteImage = null
            remoteText = null
            onRefreshTags.invoke()
        },
        state = pullState,
        modifier = Modifier.fillMaxSize()
    ) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(bottom = bottomPadding),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .background(Color.White.copy(0.06f))
                        .combinedClickable(
                            onClick = { },
                            onLongClick = { photoPicker.launch("image/*") }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (photoModel != null) {
                        AsyncImage(
                            model = photoModel,
                            contentDescription = artistName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else if (loading) {
                        CircularProgressIndicator(
                            color = Color.White.copy(0.6f),
                            modifier = Modifier.size(36.dp)
                        )
                    } else {
                        Icon(
                            Icons.Rounded.Person,
                            contentDescription = null,
                            tint = Color.White.copy(0.35f),
                            modifier = Modifier.size(72.dp)
                        )
                    }
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color.Black.copy(0.55f))
                                )
                            )
                    )
                    TextButton(
                        onClick = { photoPicker.launch("image/*") },
                        modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            if (photoModel != null) "Trocar foto" else "Adicionar foto",
                            fontSize = 12.sp,
                            color = Color.White.copy(0.9f)
                        )
                    }
                }
                Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                    Text(
                        artistName,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 2
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "${faixas(trackCount)}  ·  ${formatTotalDuration(totalDurationMs)}",
                        fontSize = 14.sp,
                        color = Color.White.copy(0.65f)
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                if (onPlayTracks != null) onPlayTracks.invoke(sortedArtistTracks, 0)
                                else onPlayAll()
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color.Black
                            )
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Tocar todas", fontWeight = FontWeight.SemiBold)
                        }
                        Button(
                            onClick = {
                                if (onPlayTracks != null) onPlayTracks.invoke(sortedArtistTracks.shuffled(), 0)
                                else onShuffle()
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White.copy(0.18f),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Rounded.Shuffle, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Aleatório", fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    if (editingInfo) {
                        OutlinedTextField(
                            value = editText,
                            onValueChange = { editText = it },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 14.sp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.White.copy(0.5f),
                                unfocusedBorderColor = Color.White.copy(0.25f),
                                cursorColor = Color.White
                            ),
                            minLines = 3,
                            maxLines = 8
                        )
                        Row(
                            Modifier.fillMaxWidth().padding(top = 8.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { editingInfo = false }) {
                                Text("Cancelar", color = Color.White.copy(0.7f))
                            }
                            TextButton(onClick = {
                                val tx = editText.trim().ifBlank { null }
                                ArtistMetaStore.saveText(context, metaKey, tx, "manual")
                                context.getSharedPreferences("wikidata_overrides", Context.MODE_PRIVATE)
                                    .edit().putString("artist_info_$artistName", tx).apply()
                                savedMeta = ArtistMetaStore.load(context, metaKey)
                                editingInfo = false
                            }) {
                                Text("Salvar", color = Color(0xFF82B1FF))
                            }
                        }
                    } else {
                        if (!displayInfo.isNullOrBlank()) {
                            Text(
                                displayInfo,
                                fontSize = 13.sp,
                                color = Color.White.copy(0.75f),
                                maxLines = if (textExpanded) Int.MAX_VALUE else 6,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.clickable { textExpanded = !textExpanded }
                            )
                        } else if (loading) {
                            Text(
                                "Buscando informações…",
                                fontSize = 13.sp,
                                color = Color.White.copy(0.45f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(
                                onClick = {
                                    editText = displayInfo ?: ""
                                    editingInfo = true
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            ) {
                                Text(
                                    if (displayInfo.isNullOrBlank()) "Adicionar info" else "Editar info",
                                    fontSize = 12.sp,
                                    color = Color(0xFF82B1FF)
                                )
                            }
                            TextButton(
                                onClick = {
                                    showManualSearch = true
                                    manualQuery = artistName
                                    runManualSearch(artistName)
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            ) {
                                Text(
                                    "Busca manual",
                                    fontSize = 12.sp,
                                    color = Color(0xFF82B1FF)
                                )
                            }
                        }
                    }
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(
                    "Álbuns",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(0.9f)
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("name" to "A–Z", "year" to "Ano").forEach { (key, label) ->
                        val sel = albumSortBy == key
                        Text(
                            label,
                            color = if (sel) Color.Black else Color.White.copy(0.85f),
                            fontSize = 13.sp,
                            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (sel) accent else Color.White.copy(0.12f))
                                .clickable { albumSortBy = key }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (albumSortAsc) "↑ Crescente" else "↓ Decrescente",
                        color = Color.White.copy(0.9f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White.copy(0.12f))
                            .clickable { albumSortAsc = !albumSortAsc }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }
        lazyGridItems(sortedAlbums, key = { it.name }) { album ->
            Column(
                Modifier
                    .padding(horizontal = 6.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onOpenAlbum(album.name) }
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White.copy(0.08f)),
                    contentAlignment = Alignment.Center
                ) {
                    if (album.artPath != null) {
                        AsyncImage(
                            model = File(album.artPath),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    album.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = Color.White
                )
                Text(
                    buildString {
                        album.year?.let { append("$it · ") }
                        append("${faixas(album.trackCount)} · ${formatTotalDuration(album.totalDurationMs)}")
                    },
                    fontSize = 12.sp,
                    color = Color.White.copy(0.55f),
                    maxLines = 1
                )
            }
        }
        if (tracks.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    "Músicas",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(0.85f),
                    modifier = Modifier.padding(start = 6.dp, top = 20.dp, bottom = 8.dp)
                )
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(
                        "Ordenar músicas",
                        fontSize = 13.sp,
                        color = Color.White.copy(0.55f),
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(
                            "album" to "Álbum",
                            "year" to "Ano",
                            "title" to "Nome",
                            "duration" to "Duração"
                        ).forEach { (key, label) ->
                            val sel = trackSortMode == key
                            Text(
                                label,
                                color = if (sel) Color.Black else Color.White.copy(0.85f),
                                fontSize = 12.sp,
                                fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (sel) accent else Color.White.copy(0.12f))
                                    .clickable { trackSortMode = key }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        Text(
                            if (trackSortAsc) "↑" else "↓",
                            color = Color.White.copy(0.9f),
                            fontSize = 14.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(0.12f))
                                .clickable { trackSortAsc = !trackSortAsc }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }
            items(sortedArtistTracks.size, key = { sortedArtistTracks[it].id }, span = { GridItemSpan(maxLineSpan) }) { index ->
                val track = sortedArtistTracks[index]
                val active = track.id == nowPlayingId
                val selected = track.id in selectedIds
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(if (selected) Color.White.copy(alpha = 0.12f) else Color.Transparent)
                        .combinedClickable(
                            onClick = {
                                if (onPlayTracks != null) onPlayTracks.invoke(sortedArtistTracks, index)
                                else onTrackClick(index, track)
                            },
                            onLongClick = { onTrackLongClick(track) }
                        )
                        .padding(horizontal = 6.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (selectionMode) {
                        Box(
                            Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (selected) {
                                Text("✓", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            track.title,
                            fontSize = 15.sp,
                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (active) accent else Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            track.album.ifBlank { "Álbum desconhecido" },
                            fontSize = 12.sp,
                            color = Color.White.copy(0.55f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        formatDuration(track.duration),
                        fontSize = 12.sp,
                        color = Color.White.copy(0.45f)
                    )
                }
                HorizontalDivider(
                    color = Color.White.copy(0.08f),
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
            }
        }
    }
    } // PullToRefreshBox

    LaunchedEffect(refreshing) {
        if (!refreshing) return@LaunchedEffect
        loading = true
        val resolved = withContext(Dispatchers.IO) {
            try { ArtistMetaStore.clear(context, metaKey) } catch (_: Exception) {}
            try {
                context.getSharedPreferences("wikidata_overrides", Context.MODE_PRIVATE)
                    .edit().remove("artist_info_$artistName").apply()
            } catch (_: Exception) {}
            val r = com.tolete.player.data.ArtistImageResolver.resolve(artistName)
            if (!r.imageUrl.isNullOrBlank()) {
                ArtistMetaStore.saveRemoteImage(context, metaKey, r.imageUrl, r.source)
            }
            if (!r.bio.isNullOrBlank()) {
                ArtistMetaStore.saveText(context, metaKey, r.bio, r.source)
            }
            r
        }
        remoteImage = resolved.imageUrl
        remoteText = resolved.bio
        savedMeta = withContext(Dispatchers.IO) { ArtistMetaStore.load(context, metaKey) }
        loading = false
        refreshing = false
    }

    if (showManualSearch) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(0.55f))
                .clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) {
                    showManualSearch = false
                },
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier
                    .fillMaxWidth(0.92f)
                    .fillMaxHeight(0.78f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xE61A1528))
                    .border(1.dp, Color.White.copy(0.14f), RoundedCornerShape(22.dp))
                    .clickable(enabled = false) {}
                    .padding(16.dp)
            ) {
                Text(
                    "Busca manual",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    "Escolha uma opção. A fonte é mostrada antes de aplicar.",
                    fontSize = 12.sp,
                    color = Color.White.copy(0.55f),
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                )
                OutlinedTextField(
                    value = manualQuery,
                    onValueChange = { manualQuery = it },
                    singleLine = true,
                    label = { Text("Nome do artista") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.White.copy(0.5f),
                        unfocusedBorderColor = Color.White.copy(0.25f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Color.White,
                        focusedLabelColor = Color.White.copy(0.7f),
                        unfocusedLabelColor = Color.White.copy(0.5f)
                    )
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { runManualSearch(manualQuery) },
                        enabled = !manualSearching && manualQuery.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                    ) {
                        Text("Buscar")
                    }
                    TextButton(onClick = { showManualSearch = false }) {
                        Text("Fechar", color = Color.White.copy(0.8f))
                    }
                }
                Spacer(Modifier.height(12.dp))
                when {
                    manualSearching -> {
                        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Color(0xFF82B1FF), modifier = Modifier.size(28.dp))
                        }
                    }
                    manualError != null -> {
                        Text(manualError!!, color = Color(0xFFFF8A80))
                    }
                    else -> {
                        androidx.compose.foundation.lazy.LazyColumn(Modifier.weight(1f)) {
                            items(manualCandidates.size) { idx ->
                                val c = manualCandidates[idx]
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 8.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color.White.copy(0.08f))
                                        .border(1.dp, Color.White.copy(0.1f), RoundedCornerShape(14.dp))
                                        .clickable {
                                            scope.launch {
                                                withContext(Dispatchers.IO) {
                                                    if (!c.imageUrl.isNullOrBlank()) {
                                                        ArtistMetaStore.saveRemoteImage(
                                                            context, metaKey, c.imageUrl, c.source
                                                        )
                                                    }
                                                    if (!c.bio.isNullOrBlank()) {
                                                        ArtistMetaStore.saveText(
                                                            context, metaKey, c.bio, c.source
                                                        )
                                                    }
                                                }
                                                remoteImage = c.imageUrl
                                                remoteText = c.bio
                                                savedMeta = withContext(Dispatchers.IO) {
                                                    ArtistMetaStore.load(context, metaKey)
                                                }
                                                showManualSearch = false
                                            }
                                        }
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (!c.imageUrl.isNullOrBlank()) {
                                        coil.compose.AsyncImage(
                                            model = c.imageUrl,
                                            contentDescription = null,
                                            modifier = Modifier
                                                .size(56.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                        )
                                        Spacer(Modifier.width(10.dp))
                                    }
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            c.source,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFF82B1FF)
                                        )
                                        if (!c.bio.isNullOrBlank()) {
                                            Text(
                                                c.bio!!.take(120) + if (c.bio!!.length > 120) "…" else "",
                                                fontSize = 11.sp,
                                                color = Color.White.copy(0.7f),
                                                maxLines = 3,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        } else {
                                            Text(
                                                "Somente imagem",
                                                fontSize = 11.sp,
                                                color = Color.White.copy(0.5f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun PlaylistTracksScreen(
    playlist: Playlist?,
    tracks: List<Track>,
    nowPlayingId: String?,
    bottomPadding: Dp,
    accent: Color,
    selectedIds: Set<String>,
    selectionMode: Boolean,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
    onTrackClick: (Int, Track) -> Unit,
    onTrackLongClick: (Track) -> Unit,
    onReorder: (List<String>) -> Unit,
    onRemove: (String) -> Unit
) {
    var organizing by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val dragScope = rememberCoroutineScope()
    var draggingId by remember { mutableStateOf<String?>(null) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }
    var dropTargetId by remember { mutableStateOf<String?>(null) }
    var dropAfter by remember { mutableStateOf(false) }
    var autoScrollJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    val order = remember { mutableStateListOf<Track>().apply { addAll(tracks) } }
    LaunchedEffect(tracks) {
        if (order.map { it.id } != tracks.map { it.id }) {
            order.clear()
            order.addAll(tracks)
        }
    }

    fun updateDropTarget() {
        val id = draggingId ?: return
        val ids = order.map { it.id }.toSet()
        val infos = listState.layoutInfo.visibleItemsInfo.filter { (it.key as? String) in ids }
        val me = infos.firstOrNull { it.key == id } ?: return
        val center = me.offset + me.size / 2f + dragOffsetY
        val target = infos.firstOrNull { center >= it.offset && center < it.offset + it.size }
            ?: if (center < (infos.firstOrNull()?.offset ?: 0)) infos.firstOrNull() else infos.lastOrNull()
        if (target == null) return
        dropTargetId = target.key as? String
        dropAfter = target.index > me.index
    }

    fun stopDrag() {
        autoScrollJob?.cancel(); autoScrollJob = null
        draggingId = null; dropTargetId = null; dragOffsetY = 0f
    }

    fun finishDrag() {
        val id = draggingId
        val targetId = dropTargetId
        if (id != null && targetId != null && targetId != id) {
            val ids = order.map { it.id }.toMutableList()
            val from = ids.indexOf(id)
            val targetIdx = ids.indexOf(targetId)
            if (from >= 0 && targetIdx >= 0) {
                val to = if (dropAfter) {
                    if (targetIdx >= from) targetIdx else targetIdx + 1
                } else {
                    if (targetIdx > from) targetIdx - 1 else targetIdx
                }.coerceIn(0, ids.lastIndex)
                if (to != from) {
                    ids.add(to, ids.removeAt(from))
                    val byId = order.associateBy { it.id }
                    order.clear()
                    order.addAll(ids.mapNotNull { byId[it] })
                    onReorder(ids)
                }
            }
        }
        stopDrag()
    }

    fun startAutoScroll() {
        autoScrollJob?.cancel()
        autoScrollJob = dragScope.launch {
            while (true) {
                val info = listState.layoutInfo
                val viewport = info.viewportEndOffset - info.viewportStartOffset
                val y = (info.visibleItemsInfo.firstOrNull { it.key == draggingId }?.let {
                    it.offset + it.size / 2f + dragOffsetY
                } ?: 0f)
                when {
                    y < info.viewportStartOffset + 80 -> listState.scrollBy(-18f)
                    y > info.viewportEndOffset - 80 -> listState.scrollBy(18f)
                }
                kotlinx.coroutines.delay(16)
            }
        }
    }

    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(bottom = bottomPadding),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                Text(
                    playlist?.name ?: "Playlist",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    "${faixas(order.size)}",
                    fontSize = 13.sp,
                    color = Color.White.copy(0.6f),
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                )
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onPlayAll,
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Tocar", fontWeight = FontWeight.SemiBold)
                    }
                    Button(
                        onClick = onShuffle,
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(0.18f), contentColor = Color.White)
                    ) {
                        Icon(Icons.Rounded.Shuffle, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Aleatório", fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        if (organizing) "Arraste para reordenar · toque no X para remover" else "Faixas",
                        fontSize = 13.sp,
                        color = Color.White.copy(0.55f)
                    )
                    TextButton(onClick = { organizing = !organizing }) {
                        Text(if (organizing) "Concluir" else "Organizar", color = Color(0xFF82B1FF))
                    }
                }
            }
        }
        items(order.size, key = { order[it].id }) { index ->
            val track = order[index]
            val active = track.id == nowPlayingId
            val selected = track.id in selectedIds
            val isDragging = draggingId == track.id
            val lineAbove = organizing && dropTargetId == track.id && !dropAfter && draggingId != track.id
            val lineBelow = organizing && dropTargetId == track.id && dropAfter && draggingId != track.id
            Box(
                Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        if (isDragging) {
                            translationY = dragOffsetY
                            alpha = 0.92f
                            shadowElevation = 12f
                        }
                    }
                    .zIndex(if (isDragging) 1f else 0f)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(if (selected) Color.White.copy(0.12f) else Color.Transparent)
                        .combinedClickable(
                            onClick = { onTrackClick(index, track) },
                            onLongClick = { onTrackLongClick(track) }
                        )
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            track.title,
                            fontSize = 16.sp,
                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (active) accent else Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            track.artist,
                            fontSize = 13.sp,
                            color = Color.White.copy(0.55f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (organizing) {
                        IconButton(onClick = { onRemove(track.id) }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Remover da playlist", tint = Color(0xFFE57373))
                        }
                        Icon(
                            Icons.Rounded.DragHandle,
                            contentDescription = "Arrastar",
                            tint = Color.White.copy(0.55f),
                            modifier = Modifier
                                .padding(start = 4.dp)
                                .size(28.dp)
                                .pointerInput(track.id) {
                                    detectDragGestures(
                                        onDragStart = {
                                            draggingId = track.id
                                            dragOffsetY = 0f
                                            dropTargetId = null
                                            updateDropTarget()
                                            startAutoScroll()
                                        },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            dragOffsetY += amount.y
                                            updateDropTarget()
                                        },
                                        onDragEnd = { finishDrag() },
                                        onDragCancel = { stopDrag() }
                                    )
                                }
                        )
                    } else {
                        Text(formatDuration(track.duration), fontSize = 12.sp, color = Color.White.copy(0.45f))
                    }
                }
                if (lineAbove) {
                    Box(
                        Modifier.align(Alignment.TopCenter).padding(horizontal = 16.dp).fillMaxWidth()
                            .height(3.dp).clip(RoundedCornerShape(2.dp)).background(accent)
                    )
                }
                if (lineBelow) {
                    Box(
                        Modifier.align(Alignment.BottomCenter).padding(horizontal = 16.dp).fillMaxWidth()
                            .height(3.dp).clip(RoundedCornerShape(2.dp)).background(accent)
                    )
                }
            }
        }
    }
}


@Composable
@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
private fun AlbumDetailScreen(
    albumName: String,
    artPath: String?,
    artists: List<String>,
    tracks: List<Track>,
    totalDurationMs: Long,
    nowPlayingId: String?,
    bottomPadding: Dp,
    accent: Color,
    selectedIds: Set<String>,
    selectionMode: Boolean,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
    onOpenArtist: (String) -> Unit,
    onTrackClick: (Int, Track) -> Unit,
    onTrackLongClick: (Track) -> Unit,
    onRefreshTags: (() -> Unit)? = null
) {
    var refreshing by remember { mutableStateOf(false) }
    val pullState = rememberPullToRefreshState()
    LaunchedEffect(refreshing) {
        if (refreshing) {
            kotlinx.coroutines.delay(1200)
            refreshing = false
        }
    }
    val discGroups = remember(tracks) {
        val hasDiscs = tracks.any { (it.discNumber ?: 0) > 1 } ||
            tracks.map { it.discNumber ?: 1 }.distinct().size > 1
        if (!hasDiscs) {
            listOf(null to tracks)
        } else {
            tracks
                .groupBy { it.discNumber ?: 1 }
                .toList()
                .sortedBy { it.first }
                .map { (disc, list) ->
                    disc to list.sortedWith(
                        compareBy({ it.trackNumber ?: Int.MAX_VALUE }, { it.title.lowercase() })
                    )
                }
        }
    }
    PullToRefreshBox(
        isRefreshing = refreshing,
        onRefresh = {
            if (onRefreshTags == null || refreshing) return@PullToRefreshBox
            refreshing = true
            onRefreshTags.invoke()
        },
        state = pullState,
        modifier = Modifier.fillMaxSize()
    ) {
    LazyColumn(
        contentPadding = PaddingValues(bottom = bottomPadding),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(240.dp)
            ) {
                if (artPath != null) {
                    AsyncImage(
                        model = File(artPath),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(Modifier.fillMaxSize().background(Color.White.copy(0.06f)))
                }
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.Transparent,
                                    Color.Black.copy(0.15f),
                                    Color.Black.copy(0.55f),
                                    Color.Black.copy(0.92f)
                                )
                            )
                        )
                )
            }
        }
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(8.dp))
                Text(
                    albumName,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 2
                )
                Spacer(Modifier.height(6.dp))
                if (artists.isNotEmpty()) {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        artists.forEach { name ->
                            Text(
                                name,
                                color = Color(0xFF82B1FF),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.clickable { onOpenArtist(name) }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "${faixas(tracks.size)}  ·  ${formatTotalDuration(totalDurationMs)}",
                    fontSize = 13.sp,
                    color = Color.White.copy(0.6f)
                )
                // Info do álbum via Wikidata (editável)
                AlbumWikiInfoSection(
                    albumName = albumName,
                    artistName = artists.firstOrNull()
                )
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onPlayAll,
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Reproduzir", fontWeight = FontWeight.SemiBold)
                    }
                    Button(
                        onClick = onShuffle,
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(0.18f),
                            contentColor = Color.White
                        )
                    ) {
                        Icon(Icons.Rounded.Shuffle, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Shuffle", fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
        // Álbuns multi-disco: seções "Disco N"
        discGroups.forEach { (disc, discTracks) ->
            if (disc != null) {
                item(key = "disc-header-$disc") {
                    Text(
                        "Disco $disc",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White.copy(0.7f),
                        modifier = Modifier.padding(start = 20.dp, top = 12.dp, bottom = 4.dp)
                    )
                }
            }
            itemsIndexed(discTracks, key = { _, t -> t.id }) { localIndex, track ->
                val index = tracks.indexOfFirst { it.id == track.id }.takeIf { it >= 0 } ?: localIndex
                val active = track.id == nowPlayingId
                val selected = track.id in selectedIds
                Column {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(if (selected) Color.White.copy(0.12f) else Color.Transparent)
                            .combinedClickable(
                                onClick = { onTrackClick(index, track) },
                                onLongClick = { onTrackLongClick(track) }
                            )
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            track.trackNumber?.toString() ?: "${localIndex + 1}",
                            fontSize = 14.sp,
                            color = Color.White.copy(0.45f),
                            modifier = Modifier.width(28.dp)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(
                                track.title,
                                fontSize = 16.sp,
                                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (active) accent else Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                track.artist,
                                fontSize = 13.sp,
                                color = Color.White.copy(0.55f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(
                            Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            tint = Color.White.copy(0.5f),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    HorizontalDivider(
                        color = Color.White.copy(0.08f),
                        modifier = Modifier.padding(horizontal = 20.dp)
                    )
                }
            }
        }
    }
    } // PullToRefreshBox
}

@Composable
private fun BatchTagEditDialog(
    count: Int,
    onDismiss: () -> Unit,
    onConfirm: (artist: String?, album: String?, albumArtist: String?, genre: String?, year: String?, trackTotal: String?, discTotal: String?) -> Unit
) {
    var artist by remember { mutableStateOf("") }
    var album by remember { mutableStateOf("") }
    var albumArtist by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var trackTotal by remember { mutableStateOf("") }
    var discTotal by remember { mutableStateOf("") }
    AppAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar tags em lote ($count faixas)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Deixe em branco os campos que não quiser alterar.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(0.6f),
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                OutlinedTextField(
                    value = artist,
                    onValueChange = { artist = it },
                    label = { Text("Artista") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )
                OutlinedTextField(
                    value = album,
                    onValueChange = { album = it },
                    label = { Text("Álbum") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )
                OutlinedTextField(
                    value = albumArtist,
                    onValueChange = { albumArtist = it },
                    label = { Text("Artista do Álbum") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )
                OutlinedTextField(
                    value = genre,
                    onValueChange = { genre = it },
                    label = { Text("Gênero") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )
                OutlinedTextField(
                    value = year,
                    onValueChange = { year = it },
                    label = { Text("Ano") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )
                OutlinedTextField(
                    value = trackTotal,
                    onValueChange = { trackTotal = it },
                    label = { Text("Total de Faixas") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )
                OutlinedTextField(
                    value = discTotal,
                    onValueChange = { discTotal = it },
                    label = { Text("Total de discos") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            val canApply = artist.isNotBlank() || album.isNotBlank() || albumArtist.isNotBlank() || genre.isNotBlank() || year.isNotBlank() || trackTotal.isNotBlank() || discTotal.isNotBlank()
            TextButton(
                onClick = {
                    onConfirm(
                        artist.takeIf { it.isNotBlank() },
                        album.takeIf { it.isNotBlank() },
                        albumArtist.takeIf { it.isNotBlank() },
                        genre.takeIf { it.isNotBlank() },
                        year.takeIf { it.isNotBlank() },
                        trackTotal.takeIf { it.isNotBlank() },
                        discTotal.takeIf { it.isNotBlank() }
                    )
                },
                enabled = canApply
            ) { Text("Aplicar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}


private val DEFAULT_RENAME_PATTERNS = listOf(
    "%ARTIST% - %TITLE%",
    "%TITLE% - %ARTIST%",
    "%TITLE% - %ALBUM%",
    "%TITLE% - %ARTIST% (%ALBUM%)",
    "%TRACK%. %TITLE%",
    "%TRACK%. %TITLE% - %ALBUM%",
    "%TRACK%. %TITLE% - %ARTIST%"
)

fun applyRenamePattern(pattern: String, track: Track): String {
    val trackNum = track.trackNumber?.toString()?.padStart(2, '0') ?: "00"
    return pattern
        .replace("%ARTIST%", track.artist)
        .replace("%TITLE%", track.title)
        .replace("%ALBUM%", track.album)
        .replace("%ALBUM_ARTIST%", track.albumArtist.ifBlank { track.artist })
        .replace("%TRACK%", trackNum)
        .replace("%YEAR%", track.year?.toString() ?: "")
        .replace("%GENRE%", track.genre)
        .replace("%COMPOSER%", "")
        .replace("%COMMENT%", "")
        .replace("%DISC_NUMBER%", "")
        .replace("%RECORD_LABEL%", "")
        .replace("%REMIXER%", "")
        .trim()
        .ifBlank { track.title }
}

@Composable
internal fun BatchRenameDialog(
    tracks: List<Track>,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var patterns by remember { mutableStateOf(DEFAULT_RENAME_PATTERNS.toMutableList()) }
    var selected by remember { mutableStateOf(patterns.first()) }
    var showAdd by remember { mutableStateOf(false) }
    var newPattern by remember { mutableStateOf("") }

    AppAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Renomear por tags (${tracks.size})") },
        text = {
            Column {
                patterns.forEach { p ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { selected = p }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selected == p, onClick = { selected = p })
                        Text(p, Modifier.padding(start = 8.dp), color = MaterialTheme.colorScheme.onSurface)
                    }
                }
                TextButton(onClick = { showAdd = true }) {
                    Text("+ Adicionar padrão")
                }
                if (showAdd) {
                    OutlinedTextField(
                        value = newPattern,
                        onValueChange = { newPattern = it },
                        label = { Text("Padrão") },
                        placeholder = { Text("%ARTIST% - %TITLE%") }
                    )
                    Text(
                        "Códigos: %ARTIST% %TITLE% %ALBUM% %ALBUM_ARTIST% %TRACK% %YEAR% %GENRE%",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = {
                        if (newPattern.isNotBlank()) {
                            patterns = (patterns + newPattern).toMutableList()
                            selected = newPattern
                            newPattern = ""
                            showAdd = false
                        }
                    }) { Text("Concluído") }
                }
                // Preview
                tracks.firstOrNull()?.let { t ->
                    Text(
                        "Ex.: ${applyRenamePattern(selected, t)}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(selected) }) { Text("Renomear") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}


@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun LysPlaceHome(
    mostPlayed: List<Track>,
    history: List<Track>,
    favorites: List<Track>,
    playlists: List<Playlist>,
    bottomPadding: androidx.compose.ui.unit.Dp,
    onPlayTracks: (List<Track>, Int) -> Unit,
    onOpenPlaylist: (String) -> Unit,
    onOpenFavorites: () -> Unit,
    onCreatePlaylist: () -> Unit,
    onImportPlaylist: () -> Unit = {},
    onExportPlaylist: (Playlist) -> Unit = {},
    onDeletePlaylist: (Playlist) -> Unit = {},
    onReorderPlaylists: (List<String>) -> Unit = {},
    playCountOf: (String) -> Int = { 0 },
    appColors: AppColors,
    homeButtonFontPath: String? = null,
    homeButtonColor: Int = 0xFFFFFFFF.toInt(),
    selectedIds: Set<String> = emptySet(),
    selectionMode: Boolean = false,
    onTrackClick: (List<Track>, Int, Track) -> Unit = { list, idx, _ -> onPlayTracks(list, idx) },
    onTrackLongClick: (Track) -> Unit = {},
    mostPlayedRanked: (MusicViewModel.MostPlayedKind, MusicViewModel.StatsPeriod) -> List<MusicViewModel.RankedItem> = { _, _ -> emptyList() },
    historyInPeriod: (MusicViewModel.StatsPeriod) -> List<Track> = { emptyList() },
    onExportTopStats: (MusicViewModel.MostPlayedKind, MusicViewModel.StatsPeriod, List<MusicViewModel.RankedItem>) -> Unit = { _, _, _ -> },
    periodPlayCount: (MusicViewModel.StatsPeriod) -> Int = { 0 },
    onOpenLastFm: () -> Unit = {}
) {
    val homeFontFamily = rememberFontFamily(homeButtonFontPath)
    val homeTextColor = Color(homeButtonColor)
    var section by remember { mutableStateOf<String?>(null) }
    var mostKind by remember { mutableStateOf(MusicViewModel.MostPlayedKind.TRACKS) }
    var mostPeriod by remember { mutableStateOf(MusicViewModel.StatsPeriod.ALL_TIME) }
    var historyPeriod by remember { mutableStateOf(MusicViewModel.StatsPeriod.ALL_TIME) }
    var showLocalRetrospective by remember { mutableStateOf(false) }
    val context = LocalContext.current
    BackHandler(enabled = section != null) { section = null }
    Box(
        Modifier
            .fillMaxSize()
            // Padding só na home; nas seções o padding vai no contentPadding da lista
            .padding(bottom = if (section == null) bottomPadding else 0.dp)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            if (section == null) {
                // Layout do desenho (proporções da foto):
                // Bloco de cima (~47%): retângulo dividido na diagonal -> Mais Tocadas (cima/esq) + Favoritas (baixo/dir)
                // Bloco de baixo (~53%): Playlists (retângulo) com Histórico em forma de cúpula na base
                Column(
                    Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                        .padding(bottom = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Bloco diagonal
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .weight(725f)
                    ) {
                        HomeLiquidGlassButton(
                            label = "MAIS\nTOCADAS",
                            defaultIconRes = R.drawable.ic_mais_tocadas_default,
                            pressedIconRes = R.drawable.ic_mais_tocadas_pressed,
                            onClick = { section = "most" },
                            shape = DiagonalCardShape(upperLeft = true, cornerDp = 30f, gapDp = 8f),
                            iconAlignment = Alignment.TopStart,
                            labelAlignment = androidx.compose.ui.BiasAlignment(-0.32f, -0.30f),
                            labelRotation = -30f,
                            fontSize = 20.sp,
                            textColor = homeTextColor,
                            fontFamily = homeFontFamily,
                            modifier = Modifier.fillMaxSize()
                        )
                        HomeLiquidGlassButton(
                            label = "FAVORITAS",
                            defaultIconRes = R.drawable.ic_favoritas_default,
                            pressedIconRes = R.drawable.ic_favoritas_pressed,
                            onClick = { section = "favorites" },
                            shape = DiagonalCardShape(upperLeft = false, cornerDp = 30f, gapDp = 8f),
                            iconAlignment = Alignment.BottomEnd,
                            labelAlignment = androidx.compose.ui.BiasAlignment(0.28f, 0.42f),
                            labelRotation = -26f,
                            fontSize = 20.sp,
                            textColor = homeTextColor,
                            fontFamily = homeFontFamily,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    // Bloco Playlists + Histórico (cúpula)
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .weight(790f)
                    ) {
                        HomeLiquidGlassButton(
                            label = "PLAYLISTS",
                            defaultIconRes = R.drawable.ic_playlists_default,
                            pressedIconRes = R.drawable.ic_playlists_pressed,
                            onClick = { section = "playlists" },
                            shape = RoundedCornerShape(26.dp),
                            iconAlignment = Alignment.TopEnd,
                            labelAlignment = androidx.compose.ui.BiasAlignment(0f, -0.64f),
                            fontSize = 20.sp,
                            textColor = homeTextColor,
                            fontFamily = homeFontFamily,
                            modifier = Modifier.fillMaxSize()
                        )
                        HomeLiquidGlassButton(
                            label = "HISTÓRICO",
                            defaultIconRes = R.drawable.ic_historico_default,
                            pressedIconRes = R.drawable.ic_historico_pressed,
                            onClick = { section = "history" },
                            shape = ArchShape(bottomCornerDp = 20f),
                            iconAlignment = Alignment.BottomStart,
                            labelAlignment = androidx.compose.ui.BiasAlignment(0f, 0.10f),
                            fontSize = 20.sp,
                            textColor = homeTextColor,
                            fontFamily = homeFontFamily,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth(0.92f)
                                .fillMaxHeight(0.67f)
                                .padding(bottom = 6.dp)
                        )
                    }
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { section = null }) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Voltar", tint = Color.White)
                    }
                    Text(
                        when (section) {
                            "most" -> "Mais Tocadas"
                            "history" -> "Histórico"
                            "playlists" -> "Playlists"
                            else -> "Favoritas"
                        },
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    if (section == "most") {
                        Spacer(Modifier.weight(1f))
                        // Atalho para o dashboard do Last.fm
                        Row(
                            Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(appColors.accent.copy(0.15f))
                                .clickable { onOpenLastFm() }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Rounded.BarChart,
                                contentDescription = "Dashboard do Last.fm",
                                tint = appColors.accent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Last.fm",
                                color = appColors.accent,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
                when (section) {
                    "most" -> {
                        val ranked = remember(mostKind, mostPeriod, mostPlayed) {
                            mostPlayedRanked(mostKind, mostPeriod)
                        }
                        Column(Modifier.fillMaxSize()) {
                            // Abas: Músicas / Artistas / Álbuns
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(
                                    MusicViewModel.MostPlayedKind.TRACKS to "Músicas",
                                    MusicViewModel.MostPlayedKind.ARTISTS to "Artistas",
                                    MusicViewModel.MostPlayedKind.ALBUMS to "Álbuns"
                                ).forEach { (kind, label) ->
                                    val sel = mostKind == kind
                                    Text(
                                        label,
                                        color = if (sel) Color.Black else Color.White.copy(0.85f),
                                        fontSize = 13.sp,
                                        fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(20.dp))
                                            .background(if (sel) appColors.accent else Color.White.copy(0.12f))
                                            .clickable { mostKind = kind }
                                            .padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                            }
                            // Períodos
                            StatsPeriodRow(
                                selected = mostPeriod,
                                accent = appColors.accent,
                                onSelect = { mostPeriod = it }
                            )
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Retrospectiva",
                                    color = appColors.accent,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(appColors.accent.copy(0.15f))
                                        .clickable {
                                            if (periodPlayCount(mostPeriod) > 0) showLocalRetrospective = true
                                            else android.widget.Toast.makeText(
                                                context,
                                                "Nada para exportar neste período",
                                                android.widget.Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "Exportar top 10",
                                    color = appColors.accent,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(appColors.accent.copy(0.15f))
                                        .clickable {
                                            val top = ranked.take(10)
                                            if (top.isEmpty()) {
                                                android.widget.Toast.makeText(
                                                    context,
                                                    "Nada para exportar neste período",
                                                    android.widget.Toast.LENGTH_SHORT
                                                ).show()
                                            } else {
                                                onExportTopStats(mostKind, mostPeriod, top)
                                            }
                                        }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                            if (ranked.isEmpty()) {
                                Text("Nenhuma reprodução registrada neste período.", color = Color.White.copy(0.6f))
                            } else {
                            androidx.compose.foundation.lazy.LazyColumn(
                                contentPadding = PaddingValues(bottom = bottomPadding + 8.dp),
                                modifier = Modifier.weight(1f).fillMaxSize()
                            ) {
                                items(ranked.size) { index ->
                                    val item = ranked[index]
                                    val isTracks = mostKind == MusicViewModel.MostPlayedKind.TRACKS
                                    val trackForRow = if (isTracks) mostPlayed.find { it.id == item.key } else null
                                    val selected = trackForRow != null && trackForRow.id in selectedIds
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .background(if (selected) Color.White.copy(alpha = 0.12f) else Color.Transparent)
                                            .then(
                                                if (isTracks && trackForRow != null) {
                                                    Modifier.combinedClickable(
                                                        onClick = {
                                                            val list = ranked.mapNotNull { r -> mostPlayed.find { it.id == r.key } }
                                                            val idx = list.indexOfFirst { it.id == trackForRow.id }.coerceAtLeast(0)
                                                            if (list.isNotEmpty()) onTrackClick(list, idx, trackForRow)
                                                        },
                                                        onLongClick = { onTrackLongClick(trackForRow) }
                                                    )
                                                } else {
                                                    Modifier.clickable {
                                                        if (item.trackIds.isNotEmpty()) {
                                                            val pool = mostPlayed.filter { it.id in item.trackIds.toSet() }
                                                                .ifEmpty { mostPlayed }
                                                            if (pool.isNotEmpty()) onPlayTracks(pool, 0)
                                                        }
                                                    }
                                                }
                                            )
                                            .padding(vertical = 10.dp, horizontal = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (selectionMode && isTracks) {
                                            Box(
                                                Modifier
                                                    .size(24.dp)
                                                    .clip(CircleShape)
                                                    .background(if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(0.2f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (selected) {
                                                    Text("✓", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                                }
                                            }
                                            Spacer(Modifier.width(10.dp))
                                        }
                                        Text(
                                            "${index + 1}",
                                            color = Color.White.copy(0.45f),
                                            fontSize = 13.sp,
                                            modifier = Modifier.width(28.dp)
                                        )
                                        Column(Modifier.weight(1f)) {
                                            Text(item.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(
                                                item.subtitle,
                                                color = Color.White.copy(0.55f),
                                                fontSize = 13.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Text(
                                            if (item.count == 1) "1 play" else "${item.count} plays",
                                            color = appColors.accent,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                            } // ranked not empty
                        } // Column most
                    }
                    "history" -> {
                        val hist = remember(historyPeriod, history) { historyInPeriod(historyPeriod) }
                        Column(Modifier.fillMaxSize()) {
                            StatsPeriodRow(
                                selected = historyPeriod,
                                accent = appColors.accent,
                                onSelect = { historyPeriod = it }
                            )
                            Spacer(Modifier.height(8.dp))
                            if (hist.isEmpty()) {
                                Text("Nenhuma faixa neste período.", color = Color.White.copy(0.6f))
                            } else {
                                TrackList(
                                    tracks = hist,
                                    nowPlayingId = null,
                                    bottomPadding = bottomPadding,
                                    showTrackNumbers = false,
                                    selectedIds = selectedIds,
                                    selectionMode = selectionMode,
                                    onClick = { index, track -> onTrackClick(hist, index, track) },
                                    onLongClick = onTrackLongClick
                                )
                            }
                        }
                    }
                    "favorites" -> {
                        if (favorites.isEmpty()) {
                            Text("Nenhuma favorita ainda.", color = Color.White.copy(0.6f))
                        } else {
                            // Lista selecionável (toque longo inicia seleção; toque alterna)
                            TrackList(
                                tracks = favorites,
                                nowPlayingId = null,
                                bottomPadding = bottomPadding,
                                showTrackNumbers = false,
                                selectedIds = selectedIds,
                                selectionMode = selectionMode,
                                onClick = { index, track -> onTrackClick(favorites, index, track) },
                                onLongClick = onTrackLongClick,
                                showAlphabetScroller = false
                            )
                        }
                    }
                    "playlists" -> {
                        PlaylistList(
                            playlists = playlists,
                            trackCount = { id ->
                                playlists.firstOrNull { it.id == id }?.trackIds?.size ?: 0
                            },
                            bottomPadding = 0.dp,
                            onOpen = onOpenPlaylist,
                            onCreate = onCreatePlaylist,
                            onImport = onImportPlaylist,
                            onExport = onExportPlaylist,
                            onDelete = onDeletePlaylist,
                            onReorder = onReorderPlaylists
                        )
                    }
                }
            }
        }
    }
    if (showLocalRetrospective) {
        val periodTitle = when (mostPeriod) {
            MusicViewModel.StatsPeriod.ALL_TIME -> "Todo o período"
            MusicViewModel.StatsPeriod.THIS_WEEK -> "Esta semana"
            MusicViewModel.StatsPeriod.LAST_WEEK -> "Semana passada"
            MusicViewModel.StatsPeriod.THIS_MONTH -> "Este mês"
            MusicViewModel.StatsPeriod.LAST_MONTH -> "Mês passado"
            MusicViewModel.StatsPeriod.THIS_YEAR -> "Este ano"
            MusicViewModel.StatsPeriod.LAST_YEAR -> "Ano passado"
        }
        val totalPlays = periodPlayCount(mostPeriod)
        val trackRows = mostPlayedRanked(MusicViewModel.MostPlayedKind.TRACKS, mostPeriod)
            .map { com.tolete.player.data.RetrospectiveExporter.ChartRow(it.title, it.subtitle, it.count) }
        val artistRows = mostPlayedRanked(MusicViewModel.MostPlayedKind.ARTISTS, mostPeriod)
            .map { com.tolete.player.data.RetrospectiveExporter.ChartRow(it.title, "", it.count) }
        val albumRows = mostPlayedRanked(MusicViewModel.MostPlayedKind.ALBUMS, mostPeriod)
            .map { com.tolete.player.data.RetrospectiveExporter.ChartRow(it.title, it.subtitle, it.count) }
        RetrospectiveExportSheet(
            description = "Período: $periodTitle\nCards montados com o histórico de reprodução local do Lyron, sem depender do Last.fm.",
            createManifest = { ctx ->
                com.tolete.player.data.RetrospectiveExporter.exportFromRaw(
                    context = ctx,
                    user = "Histórico local",
                    rangeLabel = "Local",
                    periodTitle = periodTitle,
                    totalPlays = totalPlays,
                    bucketLabels = listOf(periodTitle),
                    bucketCounts = listOf(totalPlays),
                    topTracks = trackRows,
                    topArtists = artistRows,
                    topAlbums = albumRows
                )
            },
            appColors = appColors,
            onDismiss = { showLocalRetrospective = false }
        )
    }
}

@Composable
private fun HomeLiquidGlassButton(
    label: String,
    defaultIconRes: Int,
    pressedIconRes: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(28.dp),
    iconAlignment: Alignment = Alignment.Center,
    labelAlignment: Alignment = Alignment.Center,
    labelRotation: Float = 0f,
    fontSize: androidx.compose.ui.unit.TextUnit = 16.sp,
    textColor: Color = Color.White,
    fontFamily: androidx.compose.ui.text.font.FontFamily? = null
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = if (isPressed) 0.16f else 0.26f),
                        Color.White.copy(alpha = if (isPressed) 0.05f else 0.09f),
                        Color.Black.copy(alpha = 0.10f)
                    )
                )
            )
            .border(
                width = 1.5.dp,
                brush = Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.55f),
                        Color.White.copy(alpha = 0.16f),
                        Color.White.copy(alpha = 0.05f)
                    )
                ),
                shape = shape
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        // Highlight superior estilo liquid glass
        Box(
            Modifier
                .fillMaxWidth()
                .height(20.dp)
                .align(Alignment.TopCenter)
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = if (isPressed) 0.10f else 0.20f))
        )
        // Ícone na posição inspirada no desenho
        Image(
            painter = painterResource(if (isPressed) pressedIconRes else defaultIconRes),
            contentDescription = null,
            modifier = Modifier
                .align(iconAlignment)
                .padding(14.dp)
                .size(if (iconAlignment == Alignment.Center) 44.dp else 40.dp)
                .graphicsLayer { alpha = if (isPressed) 0.85f else 1f }
        )
        // Rótulo central
        Text(
            label,
            color = textColor,
            fontWeight = FontWeight.Bold,
            fontSize = fontSize,
            fontFamily = fontFamily,
            textAlign = TextAlign.Center,
            lineHeight = fontSize * 1.2f,
            modifier = Modifier
                .align(labelAlignment)
                .padding(horizontal = 12.dp)
                .graphicsLayer { rotationZ = labelRotation },
            style = androidx.compose.ui.text.TextStyle(
                shadow = androidx.compose.ui.graphics.Shadow(
                    color = Color.Black.copy(0.45f),
                    offset = androidx.compose.ui.geometry.Offset(0f, 1.5f),
                    blurRadius = 3f
                )
            )
        )
    }
}


@Composable
internal fun FloatingIconsBackground(kind: String) {
    val baseIcons = when (kind) {
        "inicio" -> listOf(
            R.drawable.ic_float_inicio_1,
            R.drawable.ic_float_inicio_2,
            R.drawable.ic_float_inicio_3
        )
        "musicas" -> listOf(
            R.drawable.ic_float_musicas_1,
            R.drawable.ic_float_musicas_2,
            R.drawable.ic_float_musicas_3
        )
        "artistas" -> listOf(
            R.drawable.ic_float_artistas_1,
            R.drawable.ic_float_artistas_2,
            R.drawable.ic_float_artistas_3
        )
        "albuns" -> listOf(
            R.drawable.ic_float_albuns_1,
            R.drawable.ic_float_albuns_2,
            R.drawable.ic_float_albuns_3
        )
        "generos" -> listOf(
            R.drawable.ic_float_generos_1,
            R.drawable.ic_float_generos_2,
            R.drawable.ic_float_generos_3
        )
        "settings" -> listOf(
            R.drawable.ic_float_settings_1,
            R.drawable.ic_float_settings_2,
            R.drawable.ic_float_settings_3
        )
        "search" -> listOf(
            R.drawable.ic_float_search_1,
            R.drawable.ic_float_search_2,
            R.drawable.ic_float_search_3
        )
        "files" -> listOf(
            R.drawable.ic_float_files_1,
            R.drawable.ic_float_files_2,
            R.drawable.ic_float_files_3
        )
        "help" -> listOf(
            R.drawable.ic_float_help_1,
            R.drawable.ic_float_help_2,
            R.drawable.ic_float_help_3
        )
        "lastfm" -> listOf(
            R.drawable.ic_float_lastfm_1,
            R.drawable.ic_float_lastfm_2,
            R.drawable.ic_float_lastfm_3
        )
        else -> emptyList()
    }
    if (baseIcons.isEmpty()) return

    // Estilo "símbolos à deriva" (como o fundo do PPSSPP): muitos ícones pequenos e discretos,
    // cada um com sua própria direção/velocidade lenta e rotação contínua, reaparecendo do lado oposto.
    class Floater(
        val bmp: androidx.compose.ui.graphics.ImageBitmap,
        val xFrac: Float,
        val yFrac: Float,
        val sizeDp: Float,
        val baseAlpha: Float,
        val vxDp: Float,        // dp/s
        val vyDp: Float,        // dp/s
        val rot0: Float,        // graus
        val rotSpeed: Float,    // graus/s
        val phase: Float
    )

    val bitmaps = baseIcons.map { ImageBitmap.imageResource(it) }
    val floaters = remember(kind) {
        val rnd = java.util.Random(kind.hashCode().toLong())
        List(48) { i ->
            val ang = rnd.nextFloat() * (Math.PI * 2).toFloat()
            val speed = 3f + rnd.nextFloat() * 9f                       // 3–12 dp/s (lento)
            val rs = (6f + rnd.nextFloat() * 18f) * (if (rnd.nextBoolean()) 1f else -1f)
            Floater(
                bmp = bitmaps[i % bitmaps.size],
                xFrac = rnd.nextFloat(),
                yFrac = rnd.nextFloat(),
                sizeDp = if (kind == "files") 28f + rnd.nextFloat() * 16f else 20f + rnd.nextFloat() * 14f,
                baseAlpha = if (kind == "files") 0.34f + rnd.nextFloat() * 0.24f else 0.14f + rnd.nextFloat() * 0.14f,
                vxDp = kotlin.math.cos(ang) * speed,
                vyDp = kotlin.math.sin(ang) * speed,
                rot0 = rnd.nextFloat() * 360f,
                rotSpeed = rs,
                phase = rnd.nextFloat() * (Math.PI * 2).toFloat()
            )
        }
    }

    // Relógio em segundos. Lido só dentro do draw -> só redesenha, não recompõe.
    val timeSec = remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = androidx.compose.runtime.withFrameNanos { it }
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                timeSec.floatValue = (now - start) / 1_000_000_000f
            }
        }
    }

    androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
        val d = density
        val w = size.width
        val h = size.height
        val t = timeSec.floatValue
        // ~1 ícone a cada 7.500 dp² (≈ 40 ícones num celular comum)
        val wDp = w / d
        val hDp = h / d
        val count = ((wDp * hDp) / 7500f).toInt().coerceIn(24, floaters.size)
        for (i in 0 until count) {
            val f = floaters[i]
            val sz = f.sizeDp * d
            val spanX = w + sz * 2f
            val spanY = h + sz * 2f
            // posição linear com "wrap" nas bordas
            var x = (f.xFrac * w + f.vxDp * d * t + sz) % spanX
            var y = (f.yFrac * h + f.vyDp * d * t + sz) % spanY
            if (x < 0f) x += spanX
            if (y < 0f) y += spanY
            x -= sz
            y -= sz
            val rot = f.rot0 + f.rotSpeed * t
            val a = f.baseAlpha * (0.8f + 0.2f * kotlin.math.sin(t * 0.6f + f.phase))
            withTransform({
                rotate(rot, pivot = androidx.compose.ui.geometry.Offset(x + sz / 2f, y + sz / 2f))
            }) {
                drawImage(
                    image = f.bmp,
                    srcOffset = androidx.compose.ui.unit.IntOffset.Zero,
                    srcSize = androidx.compose.ui.unit.IntSize(f.bmp.width, f.bmp.height),
                    dstOffset = androidx.compose.ui.unit.IntOffset(x.toInt(), y.toInt()),
                    dstSize = androidx.compose.ui.unit.IntSize(sz.toInt(), sz.toInt()),
                    alpha = a.coerceIn(0f, 1f),
                    filterQuality = androidx.compose.ui.graphics.FilterQuality.Medium
                )
            }
        }
    }
}


/** Polígono com cantos arredondados (pontos em px). */
private fun roundedPolygonPath(pts: List<Offset>, r: Float): androidx.compose.ui.graphics.Path {
    val path = androidx.compose.ui.graphics.Path()
    val n = pts.size
    for (i in 0 until n) {
        val p0 = pts[(i + n - 1) % n]
        val p1 = pts[i]
        val p2 = pts[(i + 1) % n]
        val v1 = p0 - p1
        val v2 = p2 - p1
        val l1 = v1.getDistance()
        val l2 = v2.getDistance()
        val rr = minOf(r, l1 / 2f, l2 / 2f)
        val a = p1 + v1 * (rr / l1)
        val b = p1 + v2 * (rr / l2)
        if (i == 0) path.moveTo(a.x, a.y) else path.lineTo(a.x, a.y)
        path.quadraticBezierTo(p1.x, p1.y, b.x, b.y)
    }
    path.close()
    return path
}

/**
 * Retângulo dividido por uma diagonal (baixo-esquerda -> cima-direita), como no desenho.
 * upperLeft = true  -> metade de cima/esquerda (Mais Tocadas)
 * upperLeft = false -> metade de baixo/direita (Favoritas)
 * gapDp = espaço entre as duas metades.
 */
private class DiagonalCardShape(
    private val upperLeft: Boolean,
    private val cornerDp: Float,
    private val gapDp: Float
) : Shape {
    override fun createOutline(
        size: androidx.compose.ui.geometry.Size,
        layoutDirection: androidx.compose.ui.unit.LayoutDirection,
        density: androidx.compose.ui.unit.Density
    ): androidx.compose.ui.graphics.Outline {
        val w = size.width
        val h = size.height
        val r = cornerDp * density.density
        val half = gapDp * density.density / 2f
        // extremidades da diagonal (proporções tiradas da foto)
        val c = Offset(w * 0.03f, h * 0.985f)
        val b = Offset(w * 0.995f, h * 0.11f)
        val d = b - c
        val len = d.getDistance()
        val n = Offset(d.y / len, -d.x / len)   // normal apontando p/ cima-esquerda
        val pts = if (upperLeft) {
            val c2 = Offset((c.x + n.x * half).coerceAtLeast(0f), c.y + n.y * half)
            val b2 = Offset(b.x + n.x * half, (b.y + n.y * half).coerceAtLeast(0f))
            listOf(Offset(0f, 0f), Offset(w, 0f), b2, c2)
        } else {
            val c2 = Offset(c.x - n.x * half, (c.y - n.y * half).coerceAtMost(h))
            val b2 = Offset((b.x - n.x * half).coerceAtMost(w), b.y - n.y * half)
            listOf(b2, Offset(w, h), c2)
        }
        return androidx.compose.ui.graphics.Outline.Generic(roundedPolygonPath(pts, r))
    }
}

/** Cúpula/arco: topo arredondado largo, base reta com cantos pequenos (botão Histórico). */
private class ArchShape(private val bottomCornerDp: Float) : Shape {
    override fun createOutline(
        size: androidx.compose.ui.geometry.Size,
        layoutDirection: androidx.compose.ui.unit.LayoutDirection,
        density: androidx.compose.ui.unit.Density
    ): androidx.compose.ui.graphics.Outline {
        val w = size.width
        val h = size.height
        val r = bottomCornerDp * density.density
        val p = androidx.compose.ui.graphics.Path().apply {
            moveTo(0f, h - r)
            lineTo(0f, h * 0.50f)
            cubicTo(0f, h * 0.14f, w * 0.20f, 0f, w * 0.50f, 0f)
            cubicTo(w * 0.80f, 0f, w, h * 0.14f, w, h * 0.50f)
            lineTo(w, h - r)
            quadraticBezierTo(w, h, w - r, h)
            lineTo(r, h)
            quadraticBezierTo(0f, h, 0f, h - r)
            close()
        }
        return androidx.compose.ui.graphics.Outline.Generic(p)
    }
}

@Composable
private fun StatsPeriodRow(
    selected: MusicViewModel.StatsPeriod,
    accent: Color,
    onSelect: (MusicViewModel.StatsPeriod) -> Unit
) {
    val periods = listOf(
        MusicViewModel.StatsPeriod.ALL_TIME to "Tempo todo",
        MusicViewModel.StatsPeriod.THIS_WEEK to "Esta semana",
        MusicViewModel.StatsPeriod.LAST_WEEK to "Última semana",
        MusicViewModel.StatsPeriod.THIS_MONTH to "Este mês",
        MusicViewModel.StatsPeriod.LAST_MONTH to "Último mês",
        MusicViewModel.StatsPeriod.THIS_YEAR to "Este ano",
        MusicViewModel.StatsPeriod.LAST_YEAR to "Último ano"
    )
    androidx.compose.foundation.lazy.LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 4.dp)
    ) {
        items(periods.size) { i ->
            val (period, label) = periods[i]
            val sel = selected == period
            Text(
                label,
                color = if (sel) Color.Black else Color.White.copy(0.8f),
                fontSize = 12.sp,
                fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (sel) accent else Color.White.copy(0.1f))
                    .clickable { onSelect(period) }
                    .padding(horizontal = 12.dp, vertical = 7.dp)
            )
        }
    }
}
